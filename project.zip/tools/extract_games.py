#!/usr/bin/env python3
"""
Extracts PalMod's per-game palette tables (CGameClassByDir based games) from the
C++ headers into JSON catalogue files used by the Android port.

usage: extract_games.py <palmod/Game dir> <out dir>
"""
import json
import os
import re
import sys

GAME_DIR = sys.argv[1]
OUT_DIR = sys.argv[2]
FILEMAP = {f.lower(): f for f in os.listdir(GAME_DIR)}

# --------------------------------------------------------------------------- #
# text helpers
# --------------------------------------------------------------------------- #

def strip_comments(src: str) -> str:
    out = []
    i = 0
    n = len(src)
    while i < n:
        c = src[i]
        if c == '"':
            j = i + 1
            while j < n and src[j] != '"':
                if src[j] == '\\':
                    j += 1
                j += 1
            out.append(src[i:j + 1])
            i = j + 1
        elif c == '/' and i + 1 < n and src[i + 1] == '/':
            while i < n and src[i] != '\n':
                i += 1
        elif c == '/' and i + 1 < n and src[i + 1] == '*':
            j = src.find('*/', i + 2)
            i = n if j < 0 else j + 2
            out.append(' ')
        else:
            out.append(c)
            i += 1
    return ''.join(out)


TOKEN_RE = re.compile(r'''
    (?P<str>L?"(?:\\.|[^"\\])*")
  | (?P<num>0[xX][0-9a-fA-F]+[uUlL]*|\d+\.?\d*[uUlLfF]*)
  | (?P<id>[A-Za-z_][A-Za-z_0-9]*(?:::[A-Za-z_][A-Za-z_0-9]*)*)
  | (?P<op><<|>>|[{}()\[\],+\-*/|&~<>;=.])
''', re.X)


def tokenize(src: str):
    toks = []
    for m in TOKEN_RE.finditer(src):
        kind = m.lastgroup
        toks.append((kind, m.group(kind)))
    return toks


def unquote(tok: str) -> str:
    s = tok
    if s.startswith('L'):
        s = s[1:]
    s = s[1:-1]
    s = s.replace('\\"', '"').replace('\\\\', '\\').replace("\\'", "'")
    return s


# --------------------------------------------------------------------------- #
# per-game "world": macros, constants, declared arrays
# --------------------------------------------------------------------------- #

class World:
    def __init__(self):
        self.macros = {}      # name -> token list
        self.consts = {}      # name -> token list (expression)
        self.arrays = {}      # name -> (type, brace-tree)
        self.core = []        # (name, brace-tree)
        self.loading = {}     # name -> brace-tree
        self.crc = {}         # name -> brace-tree

    # --- brace tree: list of children; a child is either a list (nested braces) or token-list
    @staticmethod
    def parse_braces(toks, i):
        """toks[i] must be '{'; returns (tree, next_index). tree = list of items;
        each item = ('brace', tree) or ('expr', tokens)"""
        assert toks[i] == ('op', '{')
        i += 1
        items = []
        cur = []
        depth_paren = 0
        while i < len(toks):
            k, v = toks[i]
            if k == 'op' and v == '{':
                sub, i = World.parse_braces(toks, i)
                items.append(('brace', sub))
                cur = []
                continue
            if k == 'op' and v == '}':
                if cur:
                    items.append(('expr', cur))
                return items, i + 1
            if k == 'op' and v == '(':
                depth_paren += 1
            elif k == 'op' and v == ')':
                depth_paren -= 1
            if k == 'op' and v == ',' and depth_paren == 0:
                if cur:
                    items.append(('expr', cur))
                cur = []
                i += 1
                continue
            cur.append((k, v))
            i += 1
        return items, i

    def ingest(self, text: str):
        text = strip_comments(text)
        # object-like #define
        for m in re.finditer(r'^[ \t]*#define[ \t]+([A-Za-z_]\w*)[ \t]+(.+)$', text, re.M):
            self.macros[m.group(1)] = tokenize(m.group(2))
        # drop preprocessor lines for the token stream
        body = re.sub(r'^[ \t]*#.*$', '', text, flags=re.M)
        toks = tokenize(body)
        i = 0
        n = len(toks)
        while i < n:
            k, v = toks[i]
            # const sGame_PaletteDataset NAME[] = { ... };
            if k == 'id' and v in ('sGame_PaletteDataset', 'sDescTreeNode') and i + 2 < n:
                # find name
                j = i + 1
                if toks[j][0] == 'id' and j + 1 < n and toks[j + 1] == ('op', '['):
                    name = toks[j][1]
                    # advance to '='
                    while j < n and toks[j] != ('op', '='):
                        j += 1
                    j += 1
                    if j < n and toks[j] == ('op', '{'):
                        tree, j = self.parse_braces(toks, j)
                        self.arrays[name] = (v, tree)
                        i = j
                        continue
            # sCoreGameData NAME { ... };   or NAME = { ... };
            if k == 'id' and v == 'sCoreGameData' and i + 2 < n and toks[i + 1][0] == 'id':
                name = toks[i + 1][1]
                j = i + 2
                if toks[j] == ('op', '='):
                    j += 1
                if j < n and toks[j] == ('op', '{'):
                    tree, j = self.parse_braces(toks, j)
                    self.core.append((name, tree))
                    i = j
                    continue
            if k == 'id' and v == 'sDirectoryLoadingData' and i + 2 < n and toks[i + 1][0] == 'id':
                name = toks[i + 1][1]
                j = i + 2
                if toks[j] == ('op', '='):
                    j += 1
                if j < n and toks[j] == ('op', '{'):
                    tree, j = self.parse_braces(toks, j)
                    self.loading[name] = tree
                    i = j
                    continue
            # vector<sCRC32ValueSet> NAME = { ... };
            if k == 'id' and v == 'sCRC32ValueSet' and i + 3 < n and toks[i + 1] == ('op', '>') \
                    and toks[i + 2][0] == 'id':
                name = toks[i + 2][1]
                j = i + 3
                if toks[j] == ('op', '='):
                    j += 1
                if j < n and toks[j] == ('op', '{'):
                    tree, j = self.parse_braces(toks, j)
                    self.crc[name] = tree
                    i = j
                    continue
            # simple integer constants: [static] [inline] const[expr] <type> NAME = expr ;
            if k == 'id' and v in ('const', 'constexpr'):
                j = i + 1
                # skip type tokens until identifier followed by '='
                j2 = j
                while j2 < n and j2 < i + 8 and not (toks[j2][0] == 'id' and j2 + 1 < n and toks[j2 + 1] == ('op', '=')):
                    j2 += 1
                if j2 < n and j2 < i + 8 and toks[j2][0] == 'id' and toks[j2 + 1] == ('op', '='):
                    name = toks[j2][1]
                    expr = []
                    j3 = j2 + 2
                    while j3 < n and toks[j3] != ('op', ';') and toks[j3] != ('op', '{'):
                        expr.append(toks[j3])
                        j3 += 1
                    if j3 < n and toks[j3] == ('op', ';') and expr:
                        self.consts[name] = expr
            i += 1


# --------------------------------------------------------------------------- #
# expression evaluation
# --------------------------------------------------------------------------- #

class EvalError(Exception):
    pass


class Evaluator:
    def __init__(self, world: World):
        self.w = world

    def eval_tokens(self, toks, depth=0):
        if depth > 20:
            raise EvalError('recursion')
        self.toks = toks
        self.pos = 0
        self.depth = depth
        v = self._or()
        if self.pos != len(self.toks):
            raise EvalError('trailing tokens %r' % (self.toks[self.pos:],))
        return v

    # grammar: | & << >> + - * /
    def _peek(self):
        return self.toks[self.pos] if self.pos < len(self.toks) else (None, None)

    def _or(self):
        v = self._and()
        while self._peek() == ('op', '|'):
            self.pos += 1
            v |= self._and()
        return v

    def _and(self):
        v = self._shift()
        while self._peek() == ('op', '&'):
            self.pos += 1
            v &= self._shift()
        return v

    def _shift(self):
        v = self._add()
        while self._peek() in (('op', '<<'), ('op', '>>')):
            op = self._peek()[1]
            self.pos += 1
            r = self._add()
            v = (v << r) if op == '<<' else (v >> r)
        return v

    def _add(self):
        v = self._mul()
        while self._peek() in (('op', '+'), ('op', '-')):
            op = self._peek()[1]
            self.pos += 1
            r = self._mul()
            v = v + r if op == '+' else v - r
        return v

    def _mul(self):
        v = self._unary()
        while self._peek() in (('op', '*'), ('op', '/')):
            op = self._peek()[1]
            self.pos += 1
            r = self._unary()
            v = v * r if op == '*' else (v // r if r else 0)
        return v

    def _unary(self):
        k, v = self._peek()
        if (k, v) == ('op', '-'):
            self.pos += 1
            return -self._unary()
        if (k, v) == ('op', '+'):
            self.pos += 1
            return self._unary()
        if (k, v) == ('op', '~'):
            self.pos += 1
            return ~self._unary()
        return self._primary()

    def _primary(self):
        k, v = self._peek()
        if k == 'num':
            self.pos += 1
            s = re.sub(r'[uUlL]+$', '', v)
            if s.lower().startswith('0x'):
                return int(s, 16)
            if '.' in s or s.endswith(('f', 'F')):
                return float(s.rstrip('fF'))
            return int(s)
        if (k, v) == ('op', '('):
            # cast like (uint32_t)x or parenthesised expr
            save = self.pos
            self.pos += 1
            # try cast: ( id ) followed by operand start
            if self._peek()[0] == 'id' and self.pos + 1 < len(self.toks) and self.toks[self.pos + 1] == ('op', ')') \
                    and self._peek()[1] in ('uint32_t', 'uint16_t', 'uint8_t', 'int', 'size_t', 'int32_t', 'DWORD', 'unsigned', 'long'):
                self.pos += 2
                return self._unary()
            val = self._or()
            if self._peek() != ('op', ')'):
                raise EvalError('missing )')
            self.pos += 1
            return val
        if k == 'id':
            self.pos += 1
            if v in ('static_cast', 'reinterpret_cast', 'const_cast'):
                # static_cast<T>(expr)
                if self._peek() != ('op', '<'):
                    raise EvalError('cast')
                while self._peek() != ('op', '>'):
                    self.pos += 1
                self.pos += 1
                return self._primary()
            if v == 'ARRAYSIZE' or v == '_countof':
                self.pos += 1  # (
                name = self._peek()[1]
                self.pos += 1
                self.pos += 1  # )
                if name in self.w.arrays:
                    return len(self.w.arrays[name][1])
                raise EvalError('ARRAYSIZE of unknown ' + name)
            if v in ('true',):
                return 1
            if v in ('false',):
                return 0
            if v in self.w.macros:
                return Evaluator(self.w).eval_tokens(self.w.macros[v], self.depth + 1)
            if v in self.w.consts:
                return Evaluator(self.w).eval_tokens(self.w.consts[v], self.depth + 1)
            raise EvalError('unknown identifier ' + v)
        raise EvalError('unexpected %r' % ((k, v),))


def ev(world, toks):
    return Evaluator(world).eval_tokens(toks)


def str_of(world, toks):
    """String-literal expression (possibly macro-substituted / concatenated)."""
    parts = []
    for k, v in toks:
        if k == 'str':
            parts.append(unquote(v))
        elif k == 'id' and v in world.macros:
            parts.append(str_of(world, world.macros[v]))
        else:
            raise EvalError('not a string: %r' % ((k, v),))
    return ''.join(parts)


# --------------------------------------------------------------------------- #
# tree building
# --------------------------------------------------------------------------- #

class Stats:
    errors = []


def palettes_from_array(world, tree):
    pals = []
    for kind, item in tree:
        if kind != 'brace':
            continue
        fields = item
        try:
            name = str_of(world, fields[0][1])
            start = ev(world, fields[1][1])
            end = ev(world, fields[2][1])
        except EvalError as e:
            Stats.errors.append(('pal', str(e)))
            continue
        if end > start:
            pals.append([name, start, end])
    return pals


def walk_tree(world, tree, path, out_groups, shift, depth=0):
    """Resolve an sDescTreeNode array into (group-path, palettes) leaves."""
    if depth > 12:
        return
    for kind, item in tree:
        if kind != 'brace':
            continue
        fields = item
        try:
            name = str_of(world, fields[0][1])
        except EvalError as e:
            Stats.errors.append(('node-name', str(e)))
            continue
        # child pointer: look for an identifier naming a known array
        child = None
        for fk, ftoks in fields[1:]:
            if fk != 'expr':
                continue
            ids = [v for k, v in ftoks if k == 'id']
            for ident in ids:
                if ident in world.arrays:
                    child = ident
                    break
            if child:
                break
        if not child:
            continue
        ctype, ctree = world.arrays[child]
        sub_path = path + [name]
        if ctype == 'sGame_PaletteDataset':
            pals = palettes_from_array(world, ctree)
            if shift:
                pals = [[n, s + shift, e + shift] for n, s, e in pals]
            if pals:
                out_groups.append((sub_path, pals))
        else:
            walk_tree(world, ctree, sub_path, out_groups, shift, depth + 1)


def build_units(world, units_name):
    ctype, tree = world.arrays[units_name]
    units = []
    for kind, item in tree:
        if kind != 'brace':
            continue
        fields = item
        try:
            uname = str_of(world, fields[0][1])
        except EvalError as e:
            Stats.errors.append(('unit-name', str(e)))
            continue
        child = None
        for fk, ftoks in fields[1:]:
            if fk != 'expr':
                continue
            for k, v in ftoks:
                if k == 'id' and v in world.arrays:
                    child = v
                    break
            if child:
                break
        shift = 0
        # fifth field = nROMShift
        if len(fields) >= 5 and fields[4][0] == 'expr':
            try:
                shift = ev(world, fields[4][1])
            except EvalError:
                shift = 0
        if not child:
            continue
        ctype2, ctree2 = world.arrays[child]
        groups = []
        if ctype2 == 'sGame_PaletteDataset':
            pals = palettes_from_array(world, ctree2)
            if shift:
                pals = [[n, s + shift, e + shift] for n, s, e in pals]
            if pals:
                groups.append((['Palettes'], pals))
        else:
            walk_tree(world, ctree2, [], groups, shift)
        if groups:
            units.append({
                'name': uname,
                'groups': [{'name': ' / '.join(p) if p else 'Palettes', 'pals': pals} for p, pals in groups],
            })
    return units


# --------------------------------------------------------------------------- #
# core game data
# --------------------------------------------------------------------------- #

def parse_loading(world, expr_or_brace):
    """Return {'files': [[name,size],...], 'join': str} for a loading-data reference."""
    tree = None
    kind, item = expr_or_brace
    if kind == 'expr':
        ids = [v for k, v in item if k == 'id']
        for ident in ids:
            if ident in world.loading:
                tree = world.loading[ident]
                break
        if tree is None:
            raise EvalError('unknown loading data %r' % ids)
    else:
        tree = item
    # tree[0] = brace of file rules; tree[1] = join expr
    rules = tree[0][1]
    files = []
    for rk, rule in rules:
        if rk != 'brace':
            continue
        fname = str_of(world, rule[0][1])
        size = ev(world, rule[1][1])
        files.append([fname, size])
    join = 'Sequential'
    if len(tree) > 1 and tree[1][0] == 'expr':
        ids = [v for k, v in tree[1][1] if k == 'id']
        if ids:
            join = ids[0].split('::')[-1]
    return {'files': files, 'join': join}


def parse_crc(world, ident_toks):
    ids = [v for k, v in ident_toks if k == 'id']
    out = []
    tree = None
    for i in ids:
        if i in world.crc:
            tree = world.crc[i]
            break
    if tree is None:
        return out
    for kind, item in tree:
        if kind != 'brace' or len(item) < 4:
            continue
        try:
            out.append({
                'name': str_of(world, item[0][1]),
                'file': str_of(world, item[1][1]),
                'crc': ev(world, item[2][1]) & 0xFFFFFFFF,
                'offset': ev(world, item[3][1]),
            })
        except EvalError as e:
            Stats.errors.append(('crc', str(e)))
    return out


def parse_core(world, name, tree):
    fields = tree
    res = {'variantId': name}
    try:
        res['name'] = str_of(world, fields[0][1])
    except EvalError:
        return None
    alpha = None
    colmode = None
    loading = None
    crc_tokens = []
    units_name = None
    start_opt = 0
    for idx, (kind, item) in enumerate(fields):
        if kind == 'expr':
            ids = [v for k, v in item if k == 'id']
            joined = ' '.join(ids)
            if ids and ids[0].startswith('AlphaMode::'):
                alpha = ids[0].split('::')[-1]
            elif ids and ids[0].startswith('ColMode::'):
                colmode = ids[0].split('::')[-1].replace('COLMODE_', '')
            elif any(i in world.loading for i in ids):
                loading = (kind, item)
            elif any(i in world.crc for i in ids):
                crc_tokens = item
            else:
                for i in ids:
                    if i in world.arrays and world.arrays[i][0] == 'sDescTreeNode':
                        units_name = i
        else:
            # inline brace: options {NO_SPECIAL_OPTIONS, ...} or inline loading data
            flat = [v for k2, it in item if k2 == 'expr' for k, v in it if k == 'id']
            if flat and 'FileReadType' in ' '.join(flat) and loading is None:
                loading = (kind, item)
            elif flat and flat[0] in ('NO_SPECIAL_OPTIONS', 'OFFSET_PALETTE_BY_ONE'):
                start_opt = 1 if flat[0] == 'OFFSET_PALETTE_BY_ONE' else 0
            elif loading is None and item and item[0][0] == 'brace' and item[0][1] and item[0][1][0][0] == 'brace':
                loading = (kind, item)
    if not (colmode and loading and units_name):
        return None
    try:
        ld = parse_loading(world, loading)
    except (EvalError, IndexError) as e:
        Stats.errors.append(('loading', str(e)))
        return None
    res['colMode'] = colmode
    res['alpha'] = alpha or 'GameDoesNotUseAlpha'
    res['files'] = ld['files']
    res['join'] = ld['join']
    res['startPos'] = start_opt
    res['crc'] = parse_crc(world, crc_tokens)
    units = build_units(world, units_name)
    if not units:
        return None
    res['units'] = units
    try:
        res['expected'] = ev(world, fields[-2][1])
    except Exception:
        res['expected'] = None
    return res


# --------------------------------------------------------------------------- #
# driver
# --------------------------------------------------------------------------- #

def read(path):
    with open(path, 'r', encoding='utf-8-sig', errors='replace') as f:
        return f.read()


def collect_includes(path, seen):
    text = read(path)
    result = []
    for m in re.finditer(r'#include\s+"([^"]+)"', text):
        inc = m.group(1).replace('\\', '/')
        base = os.path.basename(inc)
        real = FILEMAP.get(base.lower())
        p = os.path.join(GAME_DIR, real) if real else os.path.join(GAME_DIR, base)
        if real and p not in seen and base.lower() != os.path.basename(path).lower():
            seen.add(p)
            result.extend(collect_includes(p, seen))
            result.append(p)
    return result


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    games_out = os.path.join(OUT_DIR, 'games')
    os.makedirs(games_out, exist_ok=True)
    index = []
    skipped = []
    common = [os.path.join(GAME_DIR, n) for n in ('GameDef.h', 'Default.h') if os.path.exists(os.path.join(GAME_DIR, n))]
    for fn in sorted(os.listdir(GAME_DIR)):
        if not (fn.startswith('Game_') and fn.endswith('.h')):
            continue
        path = os.path.join(GAME_DIR, fn)
        text = read(path)
        if 'CGameClassByDir' not in text or 'sCoreGameData' not in text:
            skipped.append((fn, 'not a ByDir game'))
            continue
        if fn in ('Game_DevMode_DIR.h',):
            continue
        gid = fn[len('Game_'):-2]
        world = World()
        for c in common:
            world.ingest(read(c))
        seen = set()
        incs = collect_includes(path, seen)
        for p in incs:
            world.ingest(read(p))
        world.ingest(text)
        variants = []
        for name, tree in world.core:
            try:
                v = parse_core(world, name, tree)
            except (EvalError, IndexError, AssertionError) as e:
                Stats.errors.append(('core', fn + ': ' + str(e)))
                v = None
            if v:
                variants.append(v)
        if not variants:
            skipped.append((fn, 'no parsable variants'))
            continue
        # de-duplicate variants with identical file sets + units
        title = variants[0]['name']
        entry = {'id': gid, 'name': title, 'variants': variants}
        with open(os.path.join(games_out, gid + '.json'), 'w', encoding='utf-8') as f:
            json.dump(entry, f, ensure_ascii=False, separators=(',', ':'))
        npal = sum(len(g['pals']) for u in variants[0]['units'] for g in u['groups'])
        index.append({
            'id': gid,
            'name': title,
            'colMode': variants[0]['colMode'],
            'variants': len(variants),
            'palettes': npal,
            'files': len(variants[0]['files']),
            'join': variants[0]['join'],
        })
    index.sort(key=lambda e: e['name'].lower())
    with open(os.path.join(OUT_DIR, 'index.json'), 'w', encoding='utf-8') as f:
        json.dump(index, f, ensure_ascii=False, separators=(',', ':'))
    print('games extracted:', len(index))
    print('skipped:', len(skipped))
    for s in skipped:
        print('  skip', s)
    from collections import Counter
    c = Counter(e[0] + ':' + e[1][:60] for e in Stats.errors)
    print('eval errors:', sum(c.values()))
    for k, v in c.most_common(25):
        print('  ', v, k)


if __name__ == '__main__':
    main()
