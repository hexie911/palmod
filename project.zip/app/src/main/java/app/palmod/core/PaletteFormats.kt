package app.palmod.core

/** Import / export of single palettes in common formats. Colours are COLORREF Ints (0xAABBGGRR). */
object PaletteFormats {
    enum class Format(val label: String, val ext: String, val mime: String) {
        ACT("Adobe Color Table (.act)", "act", "application/octet-stream"),
        GPL("GIMP palette (.gpl)", "gpl", "text/plain"),
        PAL("JASC palette (.pal)", "pal", "text/plain"),
        HEX("Hex list (.txt)", "txt", "text/plain"),
        PNG("Swatch image (.png)", "png", "image/png");
    }

    private fun r(c: Int) = c and 0xFF
    private fun g(c: Int) = (c ushr 8) and 0xFF
    private fun b(c: Int) = (c ushr 16) and 0xFF
    private fun mk(r: Int, g: Int, b: Int) = (0xFF shl 24) or (b shl 16) or (g shl 8) or r

    fun hex(c: Int): String = "%02X%02X%02X".format(r(c), g(c), b(c))

    fun parseHex(s: String): Int? {
        var t = s.trim().removePrefix("#").removePrefix("0x").removePrefix("0X")
        if (t.length == 3) t = t.map { "$it$it" }.joinToString("")
        if (t.length != 6 && t.length != 8) return null
        return try {
            val v = t.takeLast(6).toInt(16)
            mk((v shr 16) and 0xFF, (v shr 8) and 0xFF, v and 0xFF)
        } catch (e: NumberFormatException) { null }
    }

    fun exportAct(colors: IntArray): ByteArray {
        val out = ByteArray(772)
        for (i in 0 until minOf(256, colors.size)) {
            out[i * 3] = r(colors[i]).toByte(); out[i * 3 + 1] = g(colors[i]).toByte(); out[i * 3 + 2] = b(colors[i]).toByte()
        }
        if (colors.size < 256) { out[768] = (colors.size ushr 8).toByte(); out[769] = (colors.size and 0xFF).toByte(); out[770] = 0xFF.toByte(); out[771] = 0xFF.toByte() }
        return if (colors.size < 256) out else out.copyOf(768)
    }

    fun exportGpl(name: String, colors: IntArray): ByteArray {
        val sb = StringBuilder("GIMP Palette\nName: ${name.replace('\n', ' ')}\nColumns: 16\n#\n")
        colors.forEachIndexed { i, c -> sb.append("%3d %3d %3d\tIndex %d\n".format(r(c), g(c), b(c), i)) }
        return sb.toString().toByteArray()
    }

    fun exportJasc(colors: IntArray): ByteArray {
        val sb = StringBuilder("JASC-PAL\n0100\n${colors.size}\n")
        colors.forEach { c -> sb.append("${r(c)} ${g(c)} ${b(c)}\n") }
        return sb.toString().toByteArray()
    }

    fun exportHex(colors: IntArray): ByteArray = colors.joinToString("\n") { hex(it) }.plus("\n").toByteArray()

    fun export(format: Format, name: String, colors: IntArray): ByteArray = when (format) {
        Format.ACT -> exportAct(colors)
        Format.GPL -> exportGpl(name, colors)
        Format.PAL -> exportJasc(colors)
        Format.HEX -> exportHex(colors)
        Format.PNG -> error("PNG is rendered by the UI layer")
    }

    /** Detects ACT / JASC / GPL / hex-list and returns the colours it contains (null if unreadable). */
    fun import(bytes: ByteArray): IntArray? {
        if (bytes.isEmpty()) return null
        val head = String(bytes, 0, minOf(bytes.size, 16), Charsets.ISO_8859_1)
        val looksText = bytes.take(64).all { it.toInt() in 9..126 }
        if (!looksText) {
            // Adobe .act: 768 bytes, optionally + 4 bytes (count, transparent index)
            if (bytes.size == 768 || bytes.size == 772) {
                var n = 256
                if (bytes.size == 772) {
                    val cnt = ((bytes[768].toInt() and 0xFF) shl 8) or (bytes[769].toInt() and 0xFF)
                    if (cnt in 1..256) n = cnt
                }
                return IntArray(n) { mk(bytes[it * 3].toInt() and 0xFF, bytes[it * 3 + 1].toInt() and 0xFF, bytes[it * 3 + 2].toInt() and 0xFF) }
            }
            // RIFF PAL
            if (head.startsWith("RIFF") && bytes.size > 24) {
                val n = (bytes[22].toInt() and 0xFF) or ((bytes[23].toInt() and 0xFF) shl 8)
                if (n > 0 && bytes.size >= 24 + n * 4) {
                    return IntArray(n) { mk(bytes[24 + it * 4].toInt() and 0xFF, bytes[25 + it * 4].toInt() and 0xFF, bytes[26 + it * 4].toInt() and 0xFF) }
                }
            }
            return null
        }
        val text = String(bytes, Charsets.UTF_8)
        val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val out = ArrayList<Int>()
        if (lines.firstOrNull()?.startsWith("JASC-PAL") == true) {
            for (l in lines.drop(3)) {
                val p = l.split(Regex("\\s+"))
                if (p.size >= 3) out.add(mk(p[0].toInt().coerceIn(0, 255), p[1].toInt().coerceIn(0, 255), p[2].toInt().coerceIn(0, 255)))
            }
            return out.toIntArray().takeIf { it.isNotEmpty() }
        }
        if (lines.firstOrNull()?.startsWith("GIMP Palette") == true) {
            for (l in lines.drop(1)) {
                if (l.startsWith("#") || l.contains(":")) continue
                val p = l.split(Regex("\\s+"))
                if (p.size >= 3) {
                    val rr = p[0].toIntOrNull() ?: continue
                    val gg = p[1].toIntOrNull() ?: continue
                    val bbv = p[2].toIntOrNull() ?: continue
                    out.add(mk(rr.coerceIn(0, 255), gg.coerceIn(0, 255), bbv.coerceIn(0, 255)))
                }
            }
            return out.toIntArray().takeIf { it.isNotEmpty() }
        }
        // free text: hex colours separated by whitespace / commas
        for (tok in text.split(Regex("[\\s,;]+"))) {
            if (tok.isEmpty()) continue
            parseHex(tok)?.let { out.add(it) }
        }
        return out.toIntArray().takeIf { it.isNotEmpty() }
    }
}

/** Whole-palette colour operations used by the editor tools. */
object PaletteOps {
    fun shiftHsv(colors: IntArray, indices: Collection<Int>, hueDeg: Double, satMul: Double, valMul: Double, keepFirstTransparent: Boolean = false): IntArray {
        val out = colors.copyOf()
        for (i in indices) {
            if (i !in out.indices) continue
            if (keepFirstTransparent && i == 0) continue
            val c = out[i]
            val hsv = ColorSystem.rgbToHsv(c)
            val nh = (hsv[0] + hueDeg + 3600) % 360
            val ns = (hsv[1] * satMul).coerceIn(0.0, 1.0)
            val nv = (hsv[2] * valMul).coerceIn(0.0, 1.0)
            out[i] = ColorSystem.hsvToRgb(nh, ns, nv, ColorSystem.alphaOf(c))
        }
        return out
    }

    fun gradient(colors: IntArray, from: Int, to: Int, hsv: Boolean): IntArray {
        val out = colors.copyOf()
        val lo = minOf(from, to); val hi = maxOf(from, to)
        if (hi - lo < 2) return out
        val c0 = colors[lo]; val c1 = colors[hi]
        for (i in lo + 1 until hi) {
            out[i] = if (hsv) ColorSystem.gradientHsv(c0, c1, i - lo, hi - lo) else ColorSystem.gradientRgb(c0, c1, i - lo, hi - lo)
        }
        return out
    }

    fun reverse(colors: IntArray, indices: List<Int>): IntArray {
        val out = colors.copyOf()
        val sorted = indices.sorted()
        for (k in sorted.indices) out[sorted[k]] = colors[sorted[sorted.size - 1 - k]]
        return out
    }

    fun invert(colors: IntArray, indices: Collection<Int>): IntArray {
        val out = colors.copyOf()
        for (i in indices) {
            val c = out[i]
            out[i] = (c and 0xFF000000.toInt()) or ((255 - (c and 0xFF)) or ((255 - ((c ushr 8) and 0xFF)) shl 8) or ((255 - ((c ushr 16) and 0xFF)) shl 16))
        }
        return out
    }

    fun grayscale(colors: IntArray, indices: Collection<Int>): IntArray {
        val out = colors.copyOf()
        for (i in indices) {
            val c = out[i]
            val y = ((c and 0xFF) * 299 + ((c ushr 8) and 0xFF) * 587 + ((c ushr 16) and 0xFF) * 114) / 1000
            out[i] = (c and 0xFF000000.toInt()) or (y or (y shl 8) or (y shl 16))
        }
        return out
    }
}
