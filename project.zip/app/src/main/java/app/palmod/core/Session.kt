package app.palmod.core

import java.util.zip.CRC32

/** Result of trying to recognise the loaded ROM files against a variant's known CRC list. */
data class RomMatch(val entry: CrcEntry?, val exact: Boolean, val offset: Int, val message: String)

object RomIdentifier {
    fun crc32(data: ByteArray): Long {
        val c = CRC32(); c.update(data); return c.value
    }

    /** How many of the variant's required files were supplied (by case-insensitive name). */
    fun filesMatched(variant: Variant, supplied: List<String>): Int {
        val names = supplied.map { it.lowercase() }.toSet()
        return variant.files.count { it.name.lowercase() in names }
    }

    fun bestVariant(game: GameDef, supplied: List<String>): Variant? =
        game.variants.maxByOrNull { filesMatched(it, supplied) * 1000 + it.files.size.coerceAtMost(999) * 0 }

    fun identify(variant: Variant, files: List<RomFile>): RomMatch {
        // Prefer exact CRC hits, then filename-only hits for entries that carry no CRC.
        for (e in variant.crc) {
            val f = files.firstOrNull { it.name.equals(e.file, true) } ?: continue
            if (e.crc != 0L && crc32(f.data) == e.crc) return RomMatch(e, true, e.offset, e.name)
        }
        for (e in variant.crc) {
            val f = files.firstOrNull { it.name.equals(e.file, true) } ?: continue
            if (e.crc == 0L) return RomMatch(e, false, e.offset, e.name + " (matched by file name)")
            // a CRC exists but does not match: keep looking
            if (f.data.isEmpty()) continue
        }
        val first = variant.crc.firstOrNull { c -> files.any { it.name.equals(c.file, true) } }
        return if (first != null)
            RomMatch(first, false, first.offset, "ROM CRC does not match any known dump - addresses may be wrong")
        else RomMatch(null, false, 0, "Unrecognised ROM - using default addresses")
    }
}

/** One undoable edit of a single palette. */
private class Edit(val palIndex: Int, val before: IntArray, var after: IntArray, var time: Long = System.currentTimeMillis())

/**
 * An open game: knows the layout (variant), the ROM bytes and the editing state.
 * All palette data lives in the ROM bytes; colours are converted on demand.
 */
class Session(
    val variant: Variant,
    val rom: RomSet,
    val crcOffset: Int = 0,
    val romInfo: String = "",
) {
    val mode: ColMode = variant.colMode
    val alpha: AlphaMode = variant.alpha
    val cb: Int = mode.bytes

    private val undoStack = ArrayDeque<Edit>()
    private val redoStack = ArrayDeque<Edit>()
    private val original = HashMap<Int, IntArray>()
    val dirtyPalettes = LinkedHashSet<Int>()

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()
    val hasChanges: Boolean get() = rom.files.any { it.dirty }

    fun colorCount(def: PalDef): Int = def.colorCount(cb)
    private fun addr(def: PalDef): Long = def.start.toLong() + crcOffset

    /** True when every byte of the palette lies inside the loaded files. */
    fun isReadable(def: PalDef): Boolean {
        val n = colorCount(def)
        return n > 0 && rom.inRange(addr(def)) && rom.inRange(addr(def) + n.toLong() * cb - 1)
    }

    fun readRawPalette(def: PalDef): IntArray {
        val n = colorCount(def)
        val a = addr(def)
        return IntArray(n) { rom.readRaw(a + it.toLong() * cb, cb) }
    }

    /** Palette as COLORREF colours (0xAABBGGRR). */
    fun readPalette(def: PalDef): IntArray = readRawPalette(def).let { raws -> IntArray(raws.size) { ColorSystem.toRgb(mode, raws[it], alpha) } }

    private fun writeRawPalette(def: PalDef, raws: IntArray) {
        val a = addr(def)
        for (i in raws.indices) rom.writeRaw(a + i.toLong() * cb, cb, raws[i])
    }

    /**
     * Write edited colours. Only colours that actually changed are re-encoded, so untouched entries keep their
     * exact original bits.
     */
    fun applyPalette(def: PalDef, colors: IntArray, recordUndo: Boolean = true) {
        val before = readRawPalette(def)
        val after = before.copyOf()
        for (i in after.indices) {
            if (i >= colors.size) break
            val cur = ColorSystem.toRgb(mode, before[i], alpha)
            if (colors[i] != cur) after[i] = ColorSystem.fromRgb(mode, colors[i], before[i], alpha)
        }
        if (after.contentEquals(before)) return
        original.getOrPut(def.index) { before }
        writeRawPalette(def, after)
        dirtyPalettes.add(def.index)
        if (recordUndo) {
            val last = undoStack.lastOrNull()
            val now = System.currentTimeMillis()
            if (last != null && last.palIndex == def.index && now - last.time < 700) {
                last.after = after; last.time = now // coalesce slider drags
            } else {
                undoStack.addLast(Edit(def.index, before, after))
            }
            if (undoStack.size > 200) undoStack.removeFirst()
            redoStack.clear()
        }
        refreshDirty(def)
    }

    private fun refreshDirty(def: PalDef) {
        val orig = original[def.index]
        if (orig != null && readRawPalette(def).contentEquals(orig)) dirtyPalettes.remove(def.index) else dirtyPalettes.add(def.index)
    }

    fun revert(def: PalDef) {
        val o = original[def.index] ?: return
        val before = readRawPalette(def)
        writeRawPalette(def, o)
        undoStack.addLast(Edit(def.index, before, o.copyOf()))
        redoStack.clear()
        dirtyPalettes.remove(def.index)
    }

    fun isDirty(def: PalDef): Boolean = def.index in dirtyPalettes

    /** Undo the last edit; returns the palette that changed (so the UI can jump to it). */
    fun undo(): PalDef? {
        val e = undoStack.removeLastOrNull() ?: return null
        val def = variant.allPalettes[e.palIndex]
        writeRawPalette(def, e.before)
        redoStack.addLast(e)
        refreshDirty(def)
        return def
    }

    fun redo(): PalDef? {
        val e = redoStack.removeLastOrNull() ?: return null
        val def = variant.allPalettes[e.palIndex]
        writeRawPalette(def, e.after)
        undoStack.addLast(e)
        refreshDirty(def)
        return def
    }

    fun markSaved() {
        rom.files.forEach { it.dirty = false }
        original.clear()
        dirtyPalettes.clear()
        undoStack.clear()
        redoStack.clear()
    }

    val modifiedPaletteCount: Int get() = dirtyPalettes.size

    private val paths: Map<Int, Pair<String, String>> by lazy {
        val m = HashMap<Int, Pair<String, String>>()
        for (u in variant.units) for (g in u.groups) for (p in g.pals) m[p.index] = u.name to g.name
        m
    }
    /** (character/unit name, group name) of a palette - the "what am I editing" label. */
    fun pathOf(def: PalDef): Pair<String, String> = paths[def.index] ?: ("" to "")
}

/** Builds a free-form layout for "Developer Mode": any file, any offset, any format. */
object DevMode {
    fun variant(
        fileName: String,
        fileSize: Int,
        mode: ColMode,
        alpha: AlphaMode,
        startOffset: Int,
        colorsPerPalette: Int,
        paletteCount: Int,
    ): Variant {
        val cb = mode.bytes
        val size = colorsPerPalette * cb
        val pals = ArrayList<PalDef>()
        var idx = 0
        for (i in 0 until paletteCount) {
            val s = startOffset + i * size
            if (s + size > fileSize) break
            pals.add(PalDef(idx++, "Palette ${i + 1}  (0x%X)".format(s), s, s + size))
        }
        val groups = pals.chunked(64).mapIndexed { gi, chunk ->
            PalGroup("Palettes ${gi * 64 + 1}-${gi * 64 + chunk.size}", chunk)
        }
        return Variant(
            id = "dev", gameName = "Developer Mode: $fileName", colMode = mode, alpha = alpha,
            join = JoinType.Sequential, files = listOf(FileSpec(fileName, fileSize)), crc = emptyList(),
            units = listOf(PalUnit("File", groups)), expected = null,
        )
    }
}
