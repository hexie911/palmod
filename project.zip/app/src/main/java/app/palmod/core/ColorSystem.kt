package app.palmod.core

/*
 * Colour format engine.
 *
 * This is a line-by-line port of PalMod's ColorSystem.cpp conversion routines so that palettes edited on
 * Android are written back byte-for-byte the same way PalMod on Windows would write them.
 *
 * Conventions (same as the Windows code):
 *   - "rgb" colours are COLORREF style Ints: 0xAABBGGRR  (R in the lowest byte).
 *   - "raw" values are the integer read from the ROM for one colour (16, 24 or 32 bits wide).
 *
 * PalMod is (c) 2007-2026 PalMod team and contributors, BSD 3-clause.
 */

enum class AlphaMode {
    GameDoesNotUseAlpha,
    GameUsesFixedAlpha,
    Unknown,
    GameUsesVariableAlpha,
    GameUsesChaoticAlpha,
    GameUsesSTPNotAlpha;

    val isMutable: Boolean get() = this == GameUsesVariableAlpha

    companion object {
        fun fromName(n: String?): AlphaMode = values().firstOrNull { it.name == n } ?: GameDoesNotUseAlpha
    }
}

enum class ColMode(val label: String, val bytes: Int) {
    BGR555_LE("BGR555 little endian (GBA, PSX, SNES)", 2),
    RGB444_BE("RGB444 big endian (CPS1/CPS2)", 2),
    RGB444_LE("RGB444 little endian", 2),
    RGB555_LE_CPS3("RGB555 little endian (CPS3)", 2),
    RGB555_BE("RGB555 big endian", 2),
    RGB666_NEOGEO("RGB666 NeoGeo", 2),
    RGB333("RGB333 (Mega Drive / Genesis)", 2),
    RGBA8887("RGBA8887 (half alpha)", 4),
    RGB555_SHARP("RGB555 Sharp X68000", 2),
    RGBA8881("RGBA8881", 4),
    RGBA8888_LE("RGBA8888 little endian", 4),
    RGB888("RGB888 (24 bit)", 3),
    BGR888("BGR888 (24 bit)", 3),
    RGBA8881_32STEPS("RGBA8881 (32 steps)", 4),
    GRB555_LE("GRB555 little endian", 2),
    BGRA8888_LE("BGRA8888 little endian", 4),
    BGR555_BE("BGR555 big endian (68000)", 2),
    GRB888("GRB888 (24 bit)", 3),
    BGR333("BGR333", 2),
    RBG333("RBG333", 2),
    BGR444("BGR444", 2),
    BRG444("BRG444", 2),
    RBG444("RBG444", 2),
    BRG888("BRG888 (24 bit)", 3),
    xRGB1555_BE("xRGB1555 big endian (Saturn / Fuuki)", 2),
    RGBA8888_BE("RGBA8888 big endian", 4),
    BGRA8888_BE("BGRA8888 big endian", 4),
    BRG555_LE("BRG555 little endian", 2),
    GRB555_BE("GRB555 big endian", 2),
    RGB555_LE_NORMAL("RGB555 little endian (normal)", 2),
    RBGA8888_LE("RBGA8888 little endian", 4),
    NEOTURFMASTERS("Neo Turf Masters (unsupported)", 4),
    RGBA8888_BE16("RGBA8888 BE on 16 bit reads (Psikyo)", 4),
    RGBx5551_BE("RGBx5551 big endian (N64)", 2);

    /** Formats this port can edit. */
    val supported: Boolean get() = this != NEOTURFMASTERS

    companion object {
        fun fromName(n: String?): ColMode? = values().firstOrNull { it.name.equals(n, true) }
    }
}

object ColorSystem {
    // ---- helpers ----------------------------------------------------------------------------------------
    private fun bswap16(v: Int): Int = ((v and 0xFF) shl 8) or ((v ushr 8) and 0xFF)
    private fun bswap32(v: Int): Int = Integer.reverseBytes(v)
    private fun rr(c: Int) = c and 0xFF
    private fun gg(c: Int) = (c ushr 8) and 0xFF
    private fun bb(c: Int) = (c ushr 16) and 0xFF
    private fun aa(c: Int) = (c ushr 24) and 0xFF
    private fun pack(r: Int, g: Int, b: Int, a: Int): Int = (a shl 24) or (b shl 16) or (g shl 8) or r
    private fun roundHalfUp(d: Double): Int = Math.floor(d + 0.5).toInt() // same as C round() for >= 0
    private const val OPAQUE = 0xFF000000.toInt()

    private const val MUL333 = 36.429
    private const val MUL444 = 17.0
    private const val MUL555_CPS3 = 8
    private const val MUL555_NORMAL = 8.225

    private fun adjustedNativeAlpha(am: AlphaMode, inAlpha: Int, originalAlpha: Int, fullValue: Int): Int = when (am) {
        AlphaMode.GameUsesFixedAlpha -> fullValue and 0xFF
        AlphaMode.GameDoesNotUseAlpha -> 0
        else -> if (am.isMutable) minOf(inAlpha, fullValue) and 0xFF else originalAlpha and 0xFF
    }

    // ---- NeoGeo CLUT -------------------------------------------------------------------------------------
    private val NG = intArrayOf(
        0x00, 0x00, 0x08, 0x08, 0x0e, 0x0e, 0x15, 0x16, 0x1e, 0x1e, 0x26, 0x26, 0x2c, 0x2c, 0x33, 0x34,
        0x40, 0x41, 0x47, 0x49, 0x4d, 0x4f, 0x55, 0x56, 0x5e, 0x5f, 0x65, 0x67, 0x6b, 0x6d, 0x73, 0x75,
        0x88, 0x8a, 0x90, 0x92, 0x96, 0x98, 0x9e, 0xa0, 0xa6, 0xa9, 0xae, 0xb0, 0xb4, 0xb6, 0xbc, 0xbe,
        0xc8, 0xcb, 0xd0, 0xd3, 0xd6, 0xd9, 0xdd, 0xe1, 0xe6, 0xe9, 0xee, 0xf1, 0xf4, 0xf7, 0xfb, 0xff
    )

    private val SHARP = intArrayOf(
        0x00, 0x2e, 0x34, 0x3a, 0x40, 0x44, 0x48, 0x4e, 0x54, 0x5a, 0x60, 0x66, 0x6c, 0x72, 0x78, 0x7e,
        0x84, 0x8a, 0x90, 0x98, 0xa0, 0xa8, 0xb0, 0xb8, 0xc0, 0xca, 0xd4, 0xde, 0xe8, 0xf2, 0xfc, 0xff
    )

    private fun convert32ToNeoGeo(v: Int): Int {
        var i = 0
        while (i < NG.size) {
            if (NG[i] >= v) break
            i++
        }
        return i and 0xFF
    }

    private fun isNeoGeoColorDark(ri: Int, gi: Int, bi: Int): Boolean {
        var re = (ri / 2) == 0
        var ge = (gi / 2) == 0
        var be = (bi / 2) == 0
        if (re && ge && be) {
            re = NG[ri] != NG[ri + 1]
            ge = NG[gi] != NG[gi + 1]
            be = NG[bi] != NG[bi + 1]
        }
        return re && ge && be
    }

    private fun convert32ToSharp(v: Int): Int {
        var i = 0
        while (i < SHARP.size) {
            if (SHARP[i] >= v) break
            i++
        }
        return i and 0xFF
    }

    // ---- raw -> COLORREF ---------------------------------------------------------------------------------
    fun toRgb(mode: ColMode, raw: Int, am: AlphaMode): Int {
        val mut = am.isMutable
        when (mode) {
            ColMode.BGR333 -> {
                val r = Math.floor(((raw shr 1) and 7) * MUL333).toInt()
                val g = Math.floor(((raw shr 13) and 7) * MUL333).toInt()
                val b = Math.floor(((raw shr 9) and 7) * MUL333).toInt()
                return pack(r, g, b, 0xFF)
            }
            ColMode.RBG333 -> {
                val r = Math.floor(((raw shr 9) and 7) * MUL333).toInt()
                val g = Math.floor(((raw shr 1) and 7) * MUL333).toInt()
                val b = Math.floor(((raw shr 13) and 7) * MUL333).toInt()
                return pack(r, g, b, 0xFF)
            }
            ColMode.RGB333 -> {
                val r = Math.floor(((raw shr 9) and 7) * MUL333).toInt()
                val g = Math.floor(((raw shr 13) and 7) * MUL333).toInt()
                val b = Math.floor(((raw shr 1) and 7) * MUL333).toInt()
                return pack(r, g, b, 0xFF)
            }
            ColMode.BGR444, ColMode.BRG444, ColMode.RBG444, ColMode.RGB444_BE, ColMode.RGB444_LE -> {
                val v = if (mode == ColMode.RGB444_LE) bswap16(raw and 0xFFFF) else (raw and 0xFFFF)
                val n0 = v and 0xF
                val n1 = (v and 0xF0) shr 4
                val n2 = (v and 0xF00) shr 8
                var a = ((v and 0xF000) shr 12) * 17
                val r: Int; val g: Int; val b: Int
                when (mode) {
                    ColMode.BGR444 -> { r = n0; g = n1; b = n2 }
                    ColMode.BRG444 -> { g = n0; r = n1; b = n2 }
                    ColMode.RBG444 -> { g = n0; b = n1; r = n2 }
                    else -> { b = n0; g = n1; r = n2 } // RGB444 BE/LE
                }
                if (!mut) a = 0xFF
                return pack(r * 17, g * 17, b * 17, a)
            }
            ColMode.BGR555_LE, ColMode.BGR555_BE -> {
                val v = if (mode == ColMode.BGR555_BE) bswap16(raw and 0xFFFF) else (raw and 0xFFFF)
                var red = (v and 31) shl 3
                var green = ((v shr 5) and 31) shl 3
                var blue = ((v shr 10) and 31) shl 3
                var alpha = ((v shr 15) and 1) shl 3
                red += red / 32; green += green / 32; blue += blue / 32
                if (am == AlphaMode.GameUsesSTPNotAlpha) {
                    alpha = if (alpha != 0) 0xaf else 0xff
                } else if (alpha != 0 || !mut) {
                    alpha = 0xFF
                }
                return pack(red, green, blue, alpha)
            }
            ColMode.xRGB1555_BE -> {
                val sw = bswap16(raw and 0xFFFF)
                var a = if ((sw and 0x8000) != 0) 0xFF else 0
                var r = (sw and 0x7C00) shr 10
                var g = (sw and 0x3E0) shr 5
                var b = sw and 0x1F
                if (!mut) a = 0xFF
                r = r shl 3; g = g shl 3; b = b shl 3
                r += r / 32; g += g / 32; b += b / 32
                return pack(r, g, b, a)
            }
            ColMode.RGBx5551_BE -> {
                val le = bswap16(raw and 0xFFFF)
                val r = 8 * ((le shr 11) and 31)
                val g = 8 * ((le shr 6) and 31)
                val b = 8 * ((le shr 1) and 31)
                var a = 0xFF * (le and 1)
                if (!mut) a = 0xFF
                return pack(r, g, b, a)
            }
            ColMode.RGB555_LE_CPS3, ColMode.RGB555_LE_NORMAL -> {
                val sw = bswap16(raw and 0xFFFF)
                var a = if ((sw and 0x8000) != 0) 0xFF else 0
                var b = (sw and 0x7C00) shr 10
                var g = (sw and 0x3E0) shr 5
                var r = sw and 0x1F
                if (!mut) a = 0xFF
                r = r shl 3; g = g shl 3; b = b shl 3
                if (mode == ColMode.RGB555_LE_NORMAL) { r += r / 32; g += g / 32; b += b / 32 }
                return pack(r, g, b, a)
            }
            ColMode.GRB555_LE, ColMode.GRB555_BE -> {
                val sw = if (mode == ColMode.GRB555_LE) bswap16(raw and 0xFFFF) else (raw and 0xFFFF)
                var a = if ((sw and 0x8000) != 0) 0xFF else 0
                var b = (sw and 0x7C00) shr 10
                var r = (sw and 0x3E0) shr 5
                var g = sw and 0x1F
                if (!mut) a = 0xFF
                r = r shl 3; g = g shl 3; b = b shl 3
                r += r / 32; g += g / 32; b += b / 32
                return pack(r, g, b, a)
            }
            ColMode.BRG555_LE -> {
                val sw = bswap16(raw and 0xFFFF)
                var a = if ((sw and 0x8000) != 0) 0xFF else 0
                var g = (sw and 0x7C00) shr 10
                var r = (sw and 0x3E0) shr 5
                var b = sw and 0x1F
                if (!mut) a = 0xFF
                r = r shl 3; g = g shl 3; b = b shl 3
                r += r / 32; g += g / 32; b += b / 32
                return pack(r, g, b, a)
            }
            ColMode.RGB555_BE -> {
                val v = raw and 0xFFFF
                var a = (v and 0x8000) shr 15
                var r = (v and 0x7C00) shr 10
                var g = (v and 0x3E0) shr 5
                var b = v and 0x1F
                a = if (a != 0) 0xFF else 0
                r = r shl 3; g = g shl 3; b = b shl 3
                r += r / 32; g += g / 32; b += b / 32
                if (!mut) a = 0xFF
                return pack(r, g, b, a)
            }
            ColMode.RGB666_NEOGEO -> {
                val d = raw and 0xFFFF
                val dark = (d shr 0xf) and 1
                val red1 = ((d shr 0xe) and 1) * 2
                val redm = ((d shr 0x8) and 0xf) * 4
                val green1 = ((d shr 0xd) and 1) * 2
                val greenm = ((d shr 0x4) and 0xf) * 4
                val blue1 = ((d shr 0xc) and 1) * 2
                val bluem = ((d shr 0x0) and 0xf) * 4
                val b = NG[((blue1 + bluem) - dark) + 1]
                val g = NG[((green1 + greenm) - dark) + 1]
                val r = NG[((red1 + redm) - dark) + 1]
                return pack(r, g, b, 0xFF)
            }
            ColMode.RGB555_SHARP -> {
                val d = raw and 0xFFFF
                val bm = (d shr 0xb) and 0x1e
                val b1 = (d shr 0x3) and 0x01
                val blu = SHARP[bm + b1]
                val gm = (d shr 0x7) and 0x1e
                val g1 = (d shr 0x2) and 0x01
                val grn = SHARP[gm + g1]
                val rm = (d shr 0x3) and 0x1e
                val r1 = (d shr 0x1) and 0x01
                val red = SHARP[rm + r1]
                // NOTE: identical (swapped) layout to the Windows implementation.
                return (red shl 16) or (grn shl 8) or blu or OPAQUE
            }
            ColMode.BGR888 -> return pack((raw ushr 16) and 0xFF, (raw ushr 8) and 0xFF, raw and 0xFF, 0xFF)
            ColMode.BRG888 -> {
                val g = (raw ushr 16) and 0xFF
                val r = (raw ushr 8) and 0xFF
                val b = raw and 0xFF
                return pack(r, g, b, 0xFF)
            }
            ColMode.GRB888 -> {
                val b = (raw ushr 16) and 0xFF
                val r = (raw ushr 8) and 0xFF
                val g = raw and 0xFF
                return pack(r, g, b, 0xFF)
            }
            ColMode.RGB888 -> {
                val b = (raw ushr 16) and 0xFF
                val g = (raw ushr 8) and 0xFF
                val r = raw and 0xFF
                return pack(r, g, b, 0xFF)
            }
            ColMode.RGBA8881, ColMode.RGBA8881_32STEPS -> {
                var a = aa(raw) * 0xFF
                if (!mut) a = 0xFF
                return (bb(raw) shl 16) or (gg(raw) shl 8) or rr(raw) or (a shl 24)
            }
            ColMode.RGBA8887 -> {
                var a = minOf(aa(raw) * 2, 0xFF)
                if (!mut) a = 0xFF
                return pack(rr(raw), gg(raw), bb(raw), a)
            }
            ColMode.RBGA8888_LE -> {
                val g = bb(raw); val b = gg(raw); val r = rr(raw)
                var a = aa(raw)
                if (!mut) a = 0xFF
                return pack(r, g, b, a)
            }
            ColMode.RGBA8888_LE -> {
                var a = aa(raw)
                if (!mut) a = 0xFF
                return pack(rr(raw), gg(raw), bb(raw), a)
            }
            ColMode.RGBA8888_BE -> return toRgb(ColMode.RGBA8888_LE, bswap32(raw), am)
            ColMode.RGBA8888_BE16 -> {
                val b = (raw ushr 24) and 0xFF
                val a = if (mut) (raw ushr 16) and 0xFF else 0xFF
                val r = (raw ushr 8) and 0xFF
                val g = raw and 0xFF
                return pack(r, g, b, a)
            }
            ColMode.BGRA8888_LE -> {
                val b = rr(raw); val g = gg(raw); val r = bb(raw)
                var a = aa(raw)
                if (!mut) a = 0xFF
                return pack(r, g, b, a)
            }
            ColMode.BGRA8888_BE -> return toRgb(ColMode.BGRA8888_LE, bswap32(raw), am)
            ColMode.NEOTURFMASTERS -> return OPAQUE
        }
    }

    // ---- COLORREF -> raw ---------------------------------------------------------------------------------
    fun fromRgb(mode: ColMode, col: Int, oldRaw: Int, am: AlphaMode): Int {
        val inA = aa(col); val inB = bb(col); val inG = gg(col); val inR = rr(col)
        when (mode) {
            ColMode.BGR333 -> {
                val r = (inR + 18) / 36; val g = (inG + 18) / 36; val b = (inB + 18) / 36
                return ((r shl 1) or (b shl 9) or (g shl 13)) and 0xFFFF
            }
            ColMode.RBG333 -> {
                val r = (inR + 18) / 36; val g = (inG + 18) / 36; val b = (inB + 18) / 36
                return ((g shl 1) or (r shl 9) or (b shl 13)) and 0xFFFF
            }
            ColMode.RGB333 -> {
                val r = (inR + 18) / 36; val g = (inG + 18) / 36; val b = (inB + 18) / 36
                return ((b shl 1) or (r shl 9) or (g shl 13)) and 0xFFFF
            }
            ColMode.BGR444, ColMode.BRG444, ColMode.RBG444, ColMode.RGB444_BE, ColMode.RGB444_LE -> {
                val r = roundHalfUp(inR / 17.0)
                val g = roundHalfUp(inG / 17.0)
                val b = roundHalfUp(inB / 17.0)
                // (The Windows LE variant passes the *unswapped* old value through, so we do the same.)
                val oldV = oldRaw and 0xFFFF
                val a = adjustedNativeAlpha(am, roundHalfUp(inA / 17.0), ((oldV and 0xF000) shr 12) * 17, 0xf) shl 12
                val v = when (mode) {
                    ColMode.BGR444 -> (b shl 8) or (g shl 4) or r
                    ColMode.BRG444 -> (b shl 8) or g or (r shl 4)
                    ColMode.RBG444 -> (b shl 4) or g or (r shl 8)
                    else -> b or (g shl 4) or (r shl 8)
                } or a
                val v16 = v and 0xFFFF
                return if (mode == ColMode.RGB444_LE) bswap16(v16) else v16
            }
            ColMode.BGR555_LE, ColMode.BGR555_BE -> {
                val oldV = oldRaw and 0xFFFF // unswapped, as in the Windows code
                val a = adjustedNativeAlpha(am, inA, (oldV shr 15) and 1, 0x01)
                val v = (((inR shr 3) and 31) or (((inG shr 3) and 31) shl 5) or (((inB shr 3) and 31) shl 10)) or (a shl 15)
                val v16 = v and 0xFFFF
                return if (mode == ColMode.BGR555_BE) bswap16(v16) else v16
            }
            ColMode.xRGB1555_BE -> {
                val b = inB / 8; val g = inG / 8; val r = inR / 8
                val a = if ((oldRaw and 0x0080) != 0) 1 else 0
                return bswap16(((a shl 15) or (r shl 10) or (g shl 5) or b) and 0xFFFF)
            }
            ColMode.RGBx5551_BE -> {
                var a = if (inA != 0) 1 else 0
                val b = inB / 8; val g = inG / 8; val r = inR / 8
                a = adjustedNativeAlpha(am, a, bswap16(col and 0xFFFF) and 1, 0x1)
                return bswap16(((r shl 11) or (g shl 6) or (b shl 1) or a) and 0xFFFF)
            }
            ColMode.RGB555_LE_CPS3, ColMode.RGB555_LE_NORMAL -> {
                val b = inB / 8; val g = inG / 8; val r = inR / 8
                val a = if ((oldRaw and 0x0080) != 0) 1 else 0
                return bswap16(((a shl 15) or (b shl 10) or (g shl 5) or r) and 0xFFFF)
            }
            ColMode.GRB555_LE, ColMode.GRB555_BE -> {
                val b = inB / 8; val g = inG / 8; val r = inR / 8
                val a = if ((oldRaw and 0x0080) != 0) 1 else 0
                val v = ((a shl 15) or (b shl 10) or g or (r shl 5)) and 0xFFFF
                return if (mode == ColMode.GRB555_LE) bswap16(v) else v
            }
            ColMode.BRG555_LE -> {
                val b = inB / 8; val g = inG / 8; val r = inR / 8
                val a = if ((oldRaw and 0x0080) != 0) 1 else 0
                return bswap16(((a shl 15) or b or (g shl 10) or (r shl 5)) and 0xFFFF)
            }
            ColMode.RGB555_BE -> {
                val b = inB / 8; val g = inG / 8; val r = inR / 8
                val a = adjustedNativeAlpha(am, inA, (oldRaw and 0x8000) shr 15, 0x1) shl 15
                return (b or (g shl 5) or (r shl 10) or a) and 0xFFFF
            }
            ColMode.RGB666_NEOGEO -> {
                val r = convert32ToNeoGeo(inR); val g = convert32ToNeoGeo(inG); val b = convert32ToNeoGeo(inB)
                // The Windows code computes (but never emits) a "dark" bit; kept for parity.
                @Suppress("UNUSED_VARIABLE") val dark = isNeoGeoColorDark(minOf(r, 62), minOf(g, 62), minOf(b, 62))
                val red1 = ((r / 2) and 1) shl 0xe
                val redMain = ((r / 4) and 0xf) shl 0x8
                val green1 = ((g / 2) and 1) shl 0xd
                val greenMain = ((g / 4) and 0xf) shl 0x4
                val blue1 = ((b / 2) and 1) shl 0xc
                val blueMain = ((b / 4) and 0xf)
                return (red1 or redMain or green1 or greenMain or blue1 or blueMain) and 0xFFFF
            }
            ColMode.RGB555_SHARP -> {
                // Layout is swapped as in the Windows implementation (see toRgb).
                val r = convert32ToSharp((col ushr 16) and 0xFF)
                val g = convert32ToSharp((col ushr 8) and 0xFF)
                val b = convert32ToSharp(col and 0xFF)
                val red1 = (r and 0x01) shl 0x1
                val redMain = (r and 0x1e) shl 0x3
                val green1 = (g and 0x01) shl 0x2
                val greenMain = (g and 0x1e) shl 0x7
                val blue1 = (b and 0x01) shl 0x3
                val blueMain = (b and 0x1e) shl 0xb
                return (red1 or redMain or green1 or greenMain or blue1 or blueMain) and 0xFFFF
            }
            ColMode.BGR888 -> return (inR shl 16) or (inG shl 8) or inB
            ColMode.BRG888 -> return (inR shl 8) or (inG shl 16) or inB
            ColMode.GRB888 -> return (inR shl 8) or (inB shl 16) or inG
            ColMode.RGB888 -> return inR or (inG shl 8) or (inB shl 16)
            ColMode.RGBA8881, ColMode.RGBA8881_32STEPS -> {
                val a = adjustedNativeAlpha(am, inA, aa(oldRaw), 0x1)
                return (inB shl 16) or (inG shl 8) or inR or (a shl 24)
            }
            ColMode.RGBA8887 -> {
                val a: Int = if (!am.isMutable) adjustedNativeAlpha(am, 0x80, aa(oldRaw), 0x80)
                else Math.floor(((inA + 1) / 2).toDouble()).toInt()
                return (inB shl 16) or (inG shl 8) or inR or (a shl 24)
            }
            ColMode.RBGA8888_LE -> {
                val a = adjustedNativeAlpha(am, inA, aa(oldRaw), 0xff)
                return (inB shl 8) or (inG shl 16) or inR or (a shl 24)
            }
            ColMode.RGBA8888_LE -> {
                val a = adjustedNativeAlpha(am, inA, aa(oldRaw), 0xff)
                return (inG shl 8) or (inB shl 16) or inR or (a shl 24)
            }
            ColMode.RGBA8888_BE -> return bswap32(fromRgb(ColMode.RGBA8888_LE, col, oldRaw, am))
            ColMode.RGBA8888_BE16 -> {
                val a = adjustedNativeAlpha(am, inA, (oldRaw ushr 16) and 0xFF, 0xff)
                return (((((inB shl 8) + a) shl 8) + inR) shl 8) + inG
            }
            ColMode.BGRA8888_LE -> {
                val a = adjustedNativeAlpha(am, inA, aa(oldRaw), 0xff)
                return (inG shl 8) or (inR shl 16) or inB or (a shl 24)
            }
            ColMode.BGRA8888_BE -> return bswap32(fromRgb(ColMode.BGRA8888_LE, col, oldRaw, am))
            ColMode.NEOTURFMASTERS -> return oldRaw
        }
    }

    /** Snap an arbitrary colour to the nearest value the format can store. */
    fun snap(mode: ColMode, col: Int, oldRaw: Int, am: AlphaMode): Int = toRgb(mode, fromRgb(mode, col, oldRaw, am), am)

    // ---- editing steps (slider helpers) -------------------------------------------------------------------
    /** Number of non-zero steps a colour channel has in this format (e.g. 31 for RGB555). */
    fun planeAmt(mode: ColMode, alpha: Boolean): Int = when (mode) {
        ColMode.BGR333, ColMode.RBG333, ColMode.RGB333 -> 7
        ColMode.BGR444, ColMode.BRG444, ColMode.RBG444, ColMode.RGB444_BE, ColMode.RGB444_LE -> 15
        ColMode.BGR555_LE, ColMode.BGR555_BE, ColMode.xRGB1555_BE, ColMode.RGBx5551_BE, ColMode.RGB555_LE_NORMAL,
        ColMode.RGB555_BE, ColMode.GRB555_LE, ColMode.GRB555_BE, ColMode.BRG555_LE, ColMode.RGB555_SHARP ->
            if (alpha) 1 else 31
        ColMode.RGB555_LE_CPS3 -> if (alpha) 1 else 30
        ColMode.RGB666_NEOGEO, ColMode.NEOTURFMASTERS -> 31
        ColMode.RGBA8881 -> if (alpha) 1 else 255
        ColMode.RGBA8881_32STEPS -> if (alpha) 1 else 31
        ColMode.RGBA8887 -> if (alpha) 0x80 else 255
        else -> 255
    }

    fun stepFor8Bit(mode: ColMode, value: Int, alpha: Boolean): Int = when (planeAmt(mode, alpha)) {
        1 -> value / 255
        7 -> roundHalfUp(value / MUL333)
        15 -> roundHalfUp(value / MUL444)
        30 -> value / MUL555_CPS3
        0x80 -> halfAlphaStepFor(value)
        255 -> value
        else -> when (mode) { // 31
            ColMode.RGB666_NEOGEO, ColMode.NEOTURFMASTERS -> neoGeoStepFor(value)
            ColMode.RGB555_SHARP -> convert32ToSharp(Math.abs(value))
            else -> roundHalfUp(value / MUL555_NORMAL)
        }
    }

    fun valueForStep(mode: ColMode, step: Int, alpha: Boolean): Int = when (val p = planeAmt(mode, alpha)) {
        1 -> step * 255
        7 -> round36(roundHalfUp(MUL333 * step.coerceIn(-p, p).toDouble()))
        15 -> round17(roundHalfUp(MUL444 * step.coerceIn(-p, p).toDouble()))
        30 -> MUL555_CPS3 * step.coerceIn(-p, p)
        0x80 -> halfAlphaValueFor(step)
        255 -> step
        else -> when (mode) { // 31
            ColMode.RGB666_NEOGEO, ColMode.NEOTURFMASTERS -> neoGeoValueFor(step)
            ColMode.RGB555_SHARP -> SHARP[maxOf(0, minOf(Math.abs(step), SHARP.size) - 1)]
            else -> round8(roundHalfUp(MUL555_NORMAL * step.coerceIn(-p, p).toDouble()))
        }
    }

    private fun round8(v: Int): Int {
        val j = if (v - (((v / 8) * 8) + (v / 32)) >= 4) 1 else 0
        val r = ((v / 8) + j) * 8
        return r + (r / 32)
    }

    private fun round17(v: Int): Int = minOf(0xff, roundHalfUp(v / 17.0) * 17)
    private fun round36(v: Int): Int = minOf(255.0, roundHalfUp(v / MUL333) * MUL333).toInt()

    private fun neoGeoStepFor(v: Int): Int {
        val neg = v < 0
        var i = 1
        while (i < NG.size) { if (NG[i] >= Math.abs(v)) break; i += 2 }
        i = minOf(i, NG.size)
        i /= 2
        return i * (if (neg) -1 else 1)
    }

    private fun neoGeoValueFor(step: Int): Int {
        val neg = step < 0
        var adj = (Math.abs(step) + 1) * 2
        adj = minOf(adj, NG.size)
        adj = maxOf(0, adj - 1)
        return NG[adj] * (if (neg) -1 else 1)
    }

    private fun halfAlphaStepFor(v: Int): Int {
        var value = v
        val adj = if (value < 0) -1 else 1
        if (value % 2 == 1) value += adj
        return value / 2
    }

    private fun halfAlphaValueFor(step: Int): Int {
        val adj = if (step < 0) 1 else -1
        var v = step * 2
        if (step != 0) v += adj
        return v.coerceIn(-255, 255)
    }

    // ---- HSV / gradients ------------------------------------------------------------------------------------
    fun rgbToHsv(col: Int): DoubleArray {
        val r = rr(col) / 255.0; val g = gg(col) / 255.0; val b = bb(col) / 255.0
        val mn = minOf(r, minOf(g, b)); val mx = maxOf(r, maxOf(g, b))
        val d = mx - mn
        var h = 0.0; var s = 0.0
        val v = mx
        if (d != 0.0) {
            s = d / mx
            h = when {
                r == mx -> ((g - b) / d) % 6
                g == mx -> ((b - r) / d) + 2
                else -> ((r - g) / d) + 4
            }
            h *= 60
            if (h < 0) h += 360
        }
        return doubleArrayOf(h, s, v)
    }

    fun hsvToRgb(h0: Double, s: Double, v0: Double, alpha: Int = 0xFF): Int {
        var h = h0
        val v = v0.coerceIn(0.0, 1.0) * 255
        val sat = s.coerceIn(0.0, 1.0)
        val r: Int; val g: Int; val b: Int
        if (sat == 0.0) {
            r = v.toInt(); g = r; b = r
        } else {
            while (h >= 360) h -= 360
            while (h < 0) h += 360
            h /= 60
            val i = Math.floor(h).toInt()
            val f = h - i
            val p = (v * (1 - sat)).toInt()
            val q = (v * (1 - sat * f)).toInt()
            val t = (v * (1 - sat * (1 - f))).toInt()
            val vi = v.toInt()
            when (i) {
                0 -> { r = vi; g = t; b = p }
                1 -> { r = q; g = vi; b = p }
                2 -> { r = p; g = vi; b = t }
                3 -> { r = p; g = q; b = vi }
                4 -> { r = t; g = p; b = vi }
                else -> { r = vi; g = p; b = q }
            }
        }
        return pack(r, g, b, alpha)
    }

    fun gradientRgb(c0: Int, c1: Int, step: Int, total: Int): Int {
        if (total <= 0) return c0
        fun lerp(a: Int, b: Int) = a + (b - a) * step / total
        return pack(lerp(rr(c0), rr(c1)), lerp(gg(c0), gg(c1)), lerp(bb(c0), bb(c1)), aa(c0))
    }

    fun gradientHsv(c0: Int, c1: Int, step: Int, total: Int): Int {
        if (total <= 0) return c0
        val a = rgbToHsv(c0); val b = rgbToHsv(c1)
        var dh = b[0] - a[0]
        if (dh > 180) dh -= 360
        if (dh < -180) dh += 360
        val t = step.toDouble() / total
        return hsvToRgb(a[0] + dh * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t, aa(c0))
    }

    // Convenience accessors for the UI
    fun red(c: Int) = rr(c)
    fun green(c: Int) = gg(c)
    fun blue(c: Int) = bb(c)
    fun alphaOf(c: Int) = aa(c)
    fun rgb(r: Int, g: Int, b: Int, a: Int = 0xFF) = pack(r.coerceIn(0, 255), g.coerceIn(0, 255), b.coerceIn(0, 255), a.coerceIn(0, 255))
}
