package app.palmod.core

/** One ROM image held in memory. */
class RomFile(val name: String, var data: ByteArray, val expectedSize: Int) {
    var dirty: Boolean = false
    /** Opaque handle the UI layer uses to write the file back (a Uri, a zip entry, ...). */
    var origin: Any? = null
}

/**
 * Presents several ROM files as one virtual address space exactly the way PalMod's CGameClassByDir does:
 * sequential concatenation or one of the interleave schemes used by arcade boards.
 * Addresses are "virtual ROM" addresses as found in PalMod's palette tables.
 */
class RomSet(val files: List<RomFile>, val join: JoinType) {
    private val group = join.groupSize

    /** Where does virtual byte [v] live? -> (file index, offset in file) or null if out of range. */
    private fun locateByte(v: Long): Long? {
        var rem = v
        var base = 0
        while (base < files.size) {
            val groupFiles = minOf(group, files.size - base)
            var total = 0L
            for (k in 0 until groupFiles) total += files[base + k].expectedSize
            if (rem < total) {
                return when (join) {
                    JoinType.Sequential -> pack(base, rem)
                    JoinType.Interleaved_2FileSets -> pack(base + (rem % 2).toInt(), rem / 2)
                    JoinType.Interleaved_4FileSets -> pack(base + (rem % 4).toInt(), rem / 4)
                    JoinType.Interleaved_Read2Bytes_LE, JoinType.Interleaved_Read2Bytes_BE -> {
                        val w = rem / 2
                        val within = rem % 2
                        pack(base + (w % 2).toInt(), (w / 2) * 2 + within)
                    }
                }
            }
            rem -= total
            base += group
        }
        return null
    }

    private fun pack(file: Int, off: Long): Long = (file.toLong() shl 40) or off
    private fun fileOf(p: Long): Int = (p ushr 40).toInt()
    private fun offOf(p: Long): Int = (p and 0xFFFFFFFFFFL).toInt()

    fun inRange(v: Long): Boolean {
        val p = locateByte(v) ?: return false
        val f = files[fileOf(p)]
        return offOf(p) < f.data.size
    }

    fun read8(v: Long): Int {
        val p = locateByte(v) ?: return 0
        val d = files[fileOf(p)].data
        val o = offOf(p)
        return if (o < d.size) d[o].toInt() and 0xFF else 0
    }

    fun write8(v: Long, b: Int) {
        val p = locateByte(v) ?: return
        val f = files[fileOf(p)]
        val o = offOf(p)
        if (o < f.data.size && f.data[o] != b.toByte()) {
            f.data[o] = b.toByte()
            f.dirty = true
        }
    }

    // ---- 16-bit words in the Read2Bytes schemes ---------------------------------------------------------
    // word w (virtual 2-byte unit) -> file base + (w % 2), position (w / 2) * 2
    private fun wordLoc(vWord: Long, swapFiles: Boolean): Pair<RomFile, Int>? {
        val p = locateByte(vWord * 2) ?: return null
        // locateByte already yields BE ordering: even word -> first file of the pair
        var fi = fileOf(p)
        if (swapFiles) {
            val baseIdx = fi - (fi % group)
            fi = baseIdx + (1 - (fi - baseIdx))
        }
        return files[fi] to offOf(p)
    }

    private fun readWordLE(v: Long, swapFiles: Boolean): Int {
        val (f, o) = wordLoc(v / 2, swapFiles) ?: return 0
        return if (o + 1 < f.data.size) (f.data[o].toInt() and 0xFF) or ((f.data[o + 1].toInt() and 0xFF) shl 8) else 0
    }

    private fun writeWordLE(v: Long, swapFiles: Boolean, value: Int) {
        val (f, o) = wordLoc(v / 2, swapFiles) ?: return
        if (o + 1 < f.data.size) {
            val b0 = (value and 0xFF).toByte(); val b1 = ((value ushr 8) and 0xFF).toByte()
            if (f.data[o] != b0 || f.data[o + 1] != b1) { f.data[o] = b0; f.data[o + 1] = b1; f.dirty = true }
        }
    }

    /** Read one raw colour value of [cb] bytes (2,3,4) at virtual address [v]. */
    fun readRaw(v: Long, cb: Int): Int {
        if (join == JoinType.Interleaved_Read2Bytes_LE || join == JoinType.Interleaved_Read2Bytes_BE) {
            val le = join == JoinType.Interleaved_Read2Bytes_LE
            when (cb) {
                2 -> return readWordLE(v, le)
                4 -> {
                    val lo = readWordLE(v, false)
                    val hi = readWordLE(v + 2, false)
                    val value = (hi shl 16) or lo
                    return if (le) value else Integer.reverseBytes(value)
                }
            }
        }
        return when (cb) {
            2 -> read8(v) or (read8(v + 1) shl 8)
            3 -> (read8(v) shl 16) or (read8(v + 1) shl 8) or read8(v + 2)
            else -> read8(v) or (read8(v + 1) shl 8) or (read8(v + 2) shl 16) or (read8(v + 3) shl 24)
        }
    }

    fun writeRaw(v: Long, cb: Int, raw: Int) {
        if (join == JoinType.Interleaved_Read2Bytes_LE || join == JoinType.Interleaved_Read2Bytes_BE) {
            val le = join == JoinType.Interleaved_Read2Bytes_LE
            when (cb) {
                2 -> { writeWordLE(v, le, raw and 0xFFFF); return }
                4 -> {
                    val value = if (le) raw else Integer.reverseBytes(raw)
                    writeWordLE(v, false, value and 0xFFFF)
                    writeWordLE(v + 2, false, (value ushr 16) and 0xFFFF)
                    return
                }
            }
        }
        when (cb) {
            2 -> { write8(v, raw and 0xFF); write8(v + 1, (raw ushr 8) and 0xFF) }
            3 -> { write8(v, (raw ushr 16) and 0xFF); write8(v + 1, (raw ushr 8) and 0xFF); write8(v + 2, raw and 0xFF) }
            else -> {
                write8(v, raw and 0xFF); write8(v + 1, (raw ushr 8) and 0xFF)
                write8(v + 2, (raw ushr 16) and 0xFF); write8(v + 3, (raw ushr 24) and 0xFF)
            }
        }
    }

    val dirtyFiles: List<RomFile> get() = files.filter { it.dirty }
}
