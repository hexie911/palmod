package app.palmod.core

/** One entry in the game picker list. */
data class GameSummary(
    val id: String,
    val name: String,
    val colMode: String,
    val variants: Int,
    val palettes: Int,
    val files: Int,
    val join: String,
) {
    val supported: Boolean get() = ColMode.fromName(colMode)?.supported == true
}

enum class JoinType {
    Sequential, Interleaved_2FileSets, Interleaved_4FileSets, Interleaved_Read2Bytes_LE, Interleaved_Read2Bytes_BE;

    /** How many files make up one interleave group. */
    val groupSize: Int
        get() = when (this) {
            Sequential -> 1
            Interleaved_2FileSets, Interleaved_Read2Bytes_LE, Interleaved_Read2Bytes_BE -> 2
            Interleaved_4FileSets -> 4
        }

    companion object {
        fun fromName(n: String?): JoinType = values().firstOrNull { it.name == n } ?: Sequential
    }
}

data class FileSpec(val name: String, val size: Int)
data class CrcEntry(val name: String, val file: String, val crc: Long, val offset: Int)
data class PalDef(val index: Int, val name: String, val start: Int, val end: Int) {
    fun colorCount(bytesPerColor: Int): Int = maxOf(0, (end - start) / bytesPerColor)
}

class PalGroup(val name: String, val pals: List<PalDef>)
class PalUnit(val name: String, val groups: List<PalGroup>) {
    val paletteCount: Int get() = groups.sumOf { it.pals.size }
}

/** A concrete ROM layout for a game (several variants may exist per game: regions, bootlegs, etc.). */
class Variant(
    val id: String,
    val gameName: String,
    val colMode: ColMode,
    val alpha: AlphaMode,
    val join: JoinType,
    val files: List<FileSpec>,
    val crc: List<CrcEntry>,
    val units: List<PalUnit>,
    val expected: Int?,
) {
    val totalPalettes: Int get() = units.sumOf { it.paletteCount }
    val allPalettes: List<PalDef> by lazy { units.flatMap { u -> u.groups.flatMap { it.pals } } }
    val tableMatchesPalMod: Boolean get() = expected == null || expected == totalPalettes
}

class GameDef(val id: String, val name: String, val variants: List<Variant>)

object Catalog {
    fun parseIndex(json: String): List<GameSummary> =
        MiniJson.parse(json).asList().map {
            val m = it.asMap()
            GameSummary(
                m["id"] as String, m["name"] as String, m["colMode"] as String, m["variants"].asInt(),
                m["palettes"].asInt(), m["files"].asInt(), m["join"] as String
            )
        }

    fun parseGame(json: String): GameDef {
        val g = MiniJson.parse(json).asMap()
        val gameName = g["name"] as String
        val variants = g["variants"].asList().mapIndexedNotNull { vi, vAny ->
            val v = vAny.asMap()
            val mode = ColMode.fromName(v["colMode"] as String) ?: return@mapIndexedNotNull null
            var counter = 0
            val units = v["units"].asList().map { uAny ->
                val u = uAny.asMap()
                PalUnit(u["name"] as String, u["groups"].asList().map { gAny ->
                    val gm = gAny.asMap()
                    PalGroup(gm["name"] as String, gm["pals"].asList().map { pAny ->
                        val p = pAny.asList()
                        PalDef(counter++, p[0] as String, p[1].asInt(), p[2].asInt())
                    })
                })
            }
            Variant(
                id = (v["variantId"] as? String) ?: "v$vi",
                gameName = (v["name"] as? String) ?: gameName,
                colMode = mode,
                alpha = AlphaMode.fromName(v["alpha"] as? String),
                join = JoinType.fromName(v["join"] as? String),
                files = v["files"].asList().map { f -> val fl = f.asList(); FileSpec(fl[0] as String, fl[1].asInt()) },
                crc = v["crc"].asList().map { c ->
                    val cm = c.asMap()
                    CrcEntry(cm["name"] as String, cm["file"] as String, cm["crc"].asLong(), cm["offset"].asInt())
                },
                units = units,
                expected = (v["expected"] as? Number)?.toInt(),
            )
        }
        return GameDef(g["id"] as String, gameName, variants)
    }
}
