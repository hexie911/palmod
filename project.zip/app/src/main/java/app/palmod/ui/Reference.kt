package app.palmod.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory

/**
 * A user supplied sprite / screenshot. Every pixel is matched to the nearest colour of the palette the picture
 * was taken with, so later palette edits can be previewed live on the picture.
 */
class RefImage(val w: Int, val h: Int, private val src: IntArray) {
    private val idx = IntArray(w * h) { -1 }
    var mapped = 0
        private set

    /** [palette] = colours (0xAABBGGRR) the picture currently shows. */
    fun map(palette: IntArray, tolerance: Int) {
        val limit = 3 * tolerance * tolerance
        var n = 0
        for (i in src.indices) {
            val px = src[i]
            if ((px ushr 24) < 128) { idx[i] = -1; continue }
            val r = (px shr 16) and 0xFF; val g = (px shr 8) and 0xFF; val b = px and 0xFF
            var best = -1; var bd = Int.MAX_VALUE
            for (k in palette.indices) {
                val c = palette[k]
                val dr = r - (c and 0xFF); val dg = g - ((c shr 8) and 0xFF); val db = b - ((c shr 16) and 0xFF)
                val d = dr * dr + dg * dg + db * db
                if (d < bd) { bd = d; best = k }
            }
            if (bd <= limit) { idx[i] = best; n++ } else idx[i] = -1
        }
        mapped = n
    }

    fun render(palette: IntArray): Bitmap {
        val out = IntArray(src.size)
        for (i in src.indices) {
            val k = idx[i]
            if (k >= 0 && k < palette.size) {
                val c = palette[k]
                out[i] = (0xFF shl 24) or ((c and 0xFF) shl 16) or (((c shr 8) and 0xFF) shl 8) or ((c shr 16) and 0xFF)
            } else out[i] = src[i]
        }
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
    }

    companion object {
        fun decode(bytes: ByteArray, maxSide: Int = 320): RefImage? {
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
            val scale = maxOf(bmp.width, bmp.height).toFloat() / maxSide
            val b = if (scale > 1f) Bitmap.createScaledBitmap(bmp, (bmp.width / scale).toInt().coerceAtLeast(1), (bmp.height / scale).toInt().coerceAtLeast(1), false) else bmp
            val px = IntArray(b.width * b.height)
            b.getPixels(px, 0, b.width, 0, 0, b.width, b.height)
            return RefImage(b.width, b.height, px)
        }
    }
}
