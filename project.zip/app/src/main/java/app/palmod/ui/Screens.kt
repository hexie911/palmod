@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package app.palmod.ui

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.palmod.OpenDocsRW
import app.palmod.core.*
import java.io.ByteArrayOutputStream
import kotlin.math.roundToInt

fun cref(c: Int, opaque: Boolean = true): Color {
    val a = if (opaque) 0xFF else ColorSystem.alphaOf(c)
    return Color(red = ColorSystem.red(c) / 255f, green = ColorSystem.green(c) / 255f, blue = ColorSystem.blue(c) / 255f, alpha = a / 255f)
}

@Composable
fun PalModApp(model: AppModel) {
    val snack = remember { SnackbarHostState() }
    val msg = model.message
    LaunchedEffect(msg) {
        if (msg != null) { snack.showSnackbar(msg); model.message = null }
    }
    BackHandler(enabled = model.screen != Screen.Home) {
        when (model.screen) {
            Screen.Editor -> if (model.tab == 1) model.tab = 0 else model.closeGame()
            Screen.Setup -> model.screen = Screen.Home
            else -> model.screen = Screen.Home
        }
    }
    Scaffold(snackbarHost = { SnackbarHost(snack) }, containerColor = MaterialTheme.colorScheme.background) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (model.screen) {
                Screen.Home -> HomeScreen(model)
                Screen.Setup -> SetupScreen(model)
                Screen.Dev -> DevScreen(model)
                Screen.Editor -> EditorScreen(model)
                Screen.About -> AboutScreen(model)
            }
            if (model.busy) Box(Modifier.fillMaxSize().background(Color(0x88000000)), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        }
    }
}

// ------------------------------------------------------------------------------------------ Home

@Composable
fun HomeScreen(model: AppModel) {
    val q = model.query.trim().lowercase()
    val list = remember(model.catalog, q) { if (q.isEmpty()) model.catalog else model.catalog.filter { it.name.lowercase().contains(q) || it.id.lowercase().contains(q) } }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.background(Brush.verticalGradient(listOf(Color(0xFF2A1240), MaterialTheme.colorScheme.background))).padding(horizontal = 16.dp, vertical = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("PalMod", fontSize = 30.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                    Text("Palette editor for game ROMs - Android port", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                }
                TextButton(onClick = { model.screen = Screen.About }) { Text("About") }
            }
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = model.query, onValueChange = { model.query = it }, singleLine = true,
                modifier = Modifier.fillMaxWidth(), label = { Text("Search ${model.catalog.size} games") },
            )
            Spacer(Modifier.height(8.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                modifier = Modifier.fillMaxWidth().combinedClickable(onClick = { model.devData = null; model.screen = Screen.Dev }),
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text("Developer Mode", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSecondaryContainer)
                    Text("Open any file, choose a colour format + offset and edit raw palettes.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSecondaryContainer)
                }
            }
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list, key = { it.id }) { g ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth().combinedClickable(onClick = { model.openGame(g.id) }),
                ) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        val hue = (g.id.hashCode().and(0x7fffffff) % 360).toFloat()
                        Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(Color.hsv(hue, 0.55f, 0.85f)), contentAlignment = Alignment.Center) {
                            Text(g.name.filter { it.isLetterOrDigit() }.take(2).uppercase(), fontWeight = FontWeight.Black, color = Color(0xFF111111))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(g.name, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text("${g.palettes} palettes  -  ${g.colMode}  -  ${g.files} file(s)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (!g.supported) Text("unsupported", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

// ------------------------------------------------------------------------------------------ Setup

@Composable
fun SetupScreen(model: AppModel) {
    val g = model.game ?: return
    val picker = rememberLauncherForActivityResult(OpenDocsRW()) { uris: List<Uri> -> if (uris.isNotEmpty()) model.addFiles(uris) }
    val v = g.variants.getOrNull(model.variantIdx) ?: g.variants.first()
        var menu by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(g.name, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Select the ROM file(s) of this game from your device. You can pick several files at once, or a .zip (MAME style) and the files inside are used.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
        if (g.variants.size > 1) {
            Box {
                OutlinedButton(onClick = { menu = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Version ${model.variantIdx + 1}/${g.variants.size}: ${v.gameName}", maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    g.variants.forEachIndexed { i, vv ->
                        DropdownMenuItem(
                            text = { Text("${i + 1}. ${vv.gameName}  (${vv.files.joinToString { it.name }})", maxLines = 2) },
                            onClick = { model.setVariant(i); menu = false },
                        )
                    }
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Format: ${v.colMode.label}", fontSize = 13.sp)
                Text("Palettes: ${v.totalPalettes}   Layout: ${v.join.name.replace('_', ' ')}", fontSize = 13.sp)
                if (!v.tableMatchesPalMod) Text("Note: this table has ${v.totalPalettes} palettes while PalMod's header lists ${v.expected}. Some entries may differ.", fontSize = 12.sp, color = MaterialTheme.colorScheme.tertiary)
                HorizontalDivider(Modifier.padding(vertical = 6.dp))
                Text("Required files - tap one to choose which of your files fills it", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                v.files.forEachIndexed { i, f -> SlotRow(model, i, f) }
            }
        }
        Button(onClick = { picker.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) { Text("Choose ROM file(s)") }
        if (model.picked.isNotEmpty()) {
            Text("Loaded: " + model.picked.joinToString { it.name }, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        FilledTonalButton(onClick = { model.startGame() }, enabled = model.picked.isNotEmpty() && v.colMode.supported, modifier = Modifier.fillMaxWidth()) { Text("Open palettes") }
        if (!v.colMode.supported) Text("This colour format is not supported yet.", color = MaterialTheme.colorScheme.error)
        TextButton(onClick = { model.screen = Screen.Home }) { Text("Back") }
    }
}

// ------------------------------------------------------------------------------------------ Dev mode

@Composable
fun DevScreen(model: AppModel) {
    val opener = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u: Uri? -> if (u != null) model.readDev(u) }
    var modeIdx by rememberSaveable { mutableStateOf(ColMode.BGR555_LE.ordinal) }
    var alphaIdx by rememberSaveable { mutableStateOf(0) }
    var offset by rememberSaveable { mutableStateOf("0") }
    var colors by rememberSaveable { mutableStateOf("16") }
    var count by rememberSaveable { mutableStateOf("64") }
    var mm by remember { mutableStateOf(false) }
    var am by remember { mutableStateOf(false) }
    val modes = ColMode.values().filter { it.supported }
    val alphas = listOf(AlphaMode.GameDoesNotUseAlpha, AlphaMode.GameUsesFixedAlpha, AlphaMode.GameUsesVariableAlpha)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Developer Mode", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Edit raw palettes in any file. Offsets accept decimal or 0x hex.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
        Button(onClick = { opener.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) { Text(if (model.devData == null) "Choose file" else "File: ${model.devName} (${model.devData!!.size / 1024} KB)") }
        Box {
            OutlinedButton(onClick = { mm = true }, modifier = Modifier.fillMaxWidth()) { Text("Format: " + ColMode.values()[modeIdx].label, maxLines = 1, overflow = TextOverflow.Ellipsis) }
            DropdownMenu(expanded = mm, onDismissRequest = { mm = false }) {
                modes.forEach { m -> DropdownMenuItem(text = { Text(m.label) }, onClick = { modeIdx = m.ordinal; mm = false }) }
            }
        }
        Box {
            OutlinedButton(onClick = { am = true }, modifier = Modifier.fillMaxWidth()) { Text("Alpha: " + alphas[alphaIdx].name) }
            DropdownMenu(expanded = am, onDismissRequest = { am = false }) {
                alphas.forEachIndexed { i, a -> DropdownMenuItem(text = { Text(a.name) }, onClick = { alphaIdx = i; am = false }) }
            }
        }
        OutlinedTextField(offset, { offset = it }, label = { Text("Start offset") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(colors, { colors = it }, label = { Text("Colours per palette") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(count, { count = it }, label = { Text("Number of palettes") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
        Button(
            enabled = model.devData != null,
            onClick = {
                val off = parseNum(offset); val cpp = colors.toIntOrNull(); val cnt = count.toIntOrNull()
                if (off == null || cpp == null || cnt == null || cpp < 1 || cnt < 1) model.message = "Check the numbers."
                else model.startDev(model.devName, model.devData!!, model.devOrigin, ColMode.values()[modeIdx], alphas[alphaIdx], off, cpp, cnt)
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Open palettes") }
        TextButton(onClick = { model.screen = Screen.Home }) { Text("Back") }
    }
}

fun parseNum(s: String): Int? {
    val t = s.trim()
    return try { if (t.startsWith("0x", true)) t.substring(2).toLong(16).toInt() else t.toLong().toInt() } catch (e: NumberFormatException) { null }
}

// ------------------------------------------------------------------------------------------ About

@Composable
fun AboutScreen(model: AppModel) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("PalMod Mobile", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text("An Android port of PalMod 1.81 (palette editor for fighting-game ROMs). Colour-format conversions are ported 1:1 from the original source and verified against it; palette tables are generated from the original game modules.")
        Text("Limitations: games with custom loaders (e.g. CPS3, Marvel vs. Capcom 2, Street Fighter Alpha series, Neo Turf Masters) are not included yet - use Developer Mode for those. No sprite preview (it needs PalMod's external image data).")
        Text("Tips: tap a swatch to edit it. Turn on 'Multi' to select several colours for gradients and hue/brightness tools. ROM zips are read directly; use 'Export patched files' if the file can't be written in place.")
        HorizontalDivider()
        Text("PalMod licence (BSD 3-Clause)", fontWeight = FontWeight.SemiBold)
        Text(
            "Copyright (c) 2007-2026 PalMod contributors. All rights reserved.\n\nRedistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met: redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer; redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution; the names of the copyright holders may not be used to endorse or promote products derived from this software without specific prior written permission.\n\nTHIS SOFTWARE IS PROVIDED \"AS IS\" AND ANY EXPRESS OR IMPLIED WARRANTIES ARE DISCLAIMED. See the original PalMod-License.txt for the exact text.",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text("Always keep a backup of your ROM files before saving.", color = MaterialTheme.colorScheme.tertiary)
        OutlinedButton(onClick = { model.screen = Screen.Home }) { Text("Back") }
    }
}

// ------------------------------------------------------------------------------------------ Editor

@Composable
fun EditorScreen(model: AppModel) {
    val s = model.session ?: return
    val rev = model.rev
    val zipLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { u: Uri? -> if (u != null) model.exportZip(u) }
    var confirmExit by remember { mutableStateOf(false) }
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Column { Text(s.variant.gameName, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 16.sp); Text(if (s.modifiedPaletteCount > 0) "${s.modifiedPaletteCount} palette(s) modified" else s.romInfo.ifEmpty { "No changes" }, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis) } },
                actions = {
                    TextButton(onClick = { model.undo() }, enabled = s.canUndo) { Text("Undo") }
                    TextButton(onClick = { model.redo() }, enabled = s.canRedo) { Text("Redo") }
                    TextButton(onClick = { model.save() }, enabled = s.hasChanges) { Text("Save") }
                },
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = model.tab == 0, onClick = { model.tab = 0 }, icon = { Text("☰") }, label = { Text("Browse") })
                NavigationBarItem(selected = model.tab == 1, onClick = { model.tab = 1 }, icon = { Text("▦") }, label = { Text("Edit") })
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (model.tab == 0) BrowseTab(model, s) else EditTab(model, s)
            if (confirmExit) {
                AlertDialog(
                    onDismissRequest = { confirmExit = false },
                    confirmButton = { TextButton(onClick = { confirmExit = false; model.closeGame() }) { Text("Close anyway") } },
                    dismissButton = { TextButton(onClick = { confirmExit = false }) { Text("Cancel") } },
                    title = { Text("Unsaved changes") }, text = { Text("Close this game and lose unsaved edits?") },
                )
            }
        }
    }
    if (model.needZipExport) {
        AlertDialog(
            onDismissRequest = { model.needZipExport = false },
            confirmButton = { TextButton(onClick = { zipLauncher.launch("palmod_patched.zip") }) { Text("Export patched files (.zip)") } },
            dismissButton = { TextButton(onClick = { model.needZipExport = false }) { Text("Later") } },
            title = { Text("Could not save in place") },
            text = { Text("The file location does not allow writing (or it came from a zip). Export the patched files as a zip instead.") },
        )
    }
    // keep rev referenced so the screen recomposes on edits
    if (rev < 0) Text("")
}

private class BrowseRow(val kind: Int, val text: String, val unit: Int, val def: PalDef?, val count: Int = 0)

@Composable
fun BrowseTab(model: AppModel, s: Session) {
    val rev = model.rev
    var q by rememberSaveable { mutableStateOf("") }
    val expanded = remember { mutableStateListOf<Int>() }
    val rows = remember(s, q, expanded.toList(), rev) {
        val out = ArrayList<BrowseRow>()
        val ql = q.trim().lowercase()
        if (ql.isNotEmpty()) {
            var n = 0
            loop@ for ((ui, u) in s.variant.units.withIndex()) for (gr in u.groups) for (p in gr.pals) {
                if (u.name.lowercase().contains(ql) || p.name.lowercase().contains(ql) || gr.name.lowercase().contains(ql)) {
                    out.add(BrowseRow(2, u.name + "  -  " + p.name, ui, p)); n++
                    if (n >= 300) break@loop
                }
            }
        } else {
            for ((ui, u) in s.variant.units.withIndex()) {
                out.add(BrowseRow(0, u.name, ui, null, u.paletteCount))
                if (ui in expanded) for (gr in u.groups) {
                    if (u.groups.size > 1) out.add(BrowseRow(1, gr.name, ui, null))
                    for (p in gr.pals) out.add(BrowseRow(2, p.name, ui, p))
                }
            }
        }
        out
    }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(q, { q = it }, singleLine = true, label = { Text("Search character / palette") }, modifier = Modifier.fillMaxWidth().padding(12.dp))
        LazyColumn(Modifier.fillMaxSize()) {
            items(rows.size) { i ->
                val r = rows[i]
                when (r.kind) {
                    0 -> Row(
                        Modifier.fillMaxWidth().combinedClickable(onClick = { if (r.unit in expanded) expanded.remove(r.unit) else expanded.add(r.unit) })
                            .background(MaterialTheme.colorScheme.surfaceVariant).padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(r.text, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text("${r.count}  " + if (r.unit in expanded) "▲" else "▼", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    1 -> Text(r.text, fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(start = 20.dp, top = 8.dp, bottom = 2.dp))
                    else -> {
                        val d = r.def!!
                        val cur = model.currentPal?.index == d.index
                        val readable = s.isReadable(d)
                        Row(
                            Modifier.fillMaxWidth().combinedClickable(enabled = readable, onClick = { model.selectPalette(d) })
                                .background(if (cur) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                                .padding(horizontal = 20.dp, vertical = 11.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            if (readable) MiniStrip(s.readPalette(d), Modifier.width(64.dp).height(14.dp)) else Spacer(Modifier.width(64.dp))
                            Spacer(Modifier.width(12.dp))
                            Text(r.text, modifier = Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp,
                                color = if (readable) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant)
                            if (s.isDirty(d)) Box(Modifier.size(8.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MiniStrip(colors: IntArray, modifier: Modifier) {
    Row(modifier.clip(RoundedCornerShape(3.dp))) {
        val n = minOf(colors.size, 16)
        for (i in 0 until n) {
            val idx = if (colors.size <= 16) i else i * colors.size / 16
            Box(Modifier.weight(1f).fillMaxSize().background(cref(colors[idx])))
        }
    }
}

@Composable
fun EditTab(model: AppModel, s: Session) {
    val rev = model.rev
    val def = model.currentPal
    if (def == null) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Pick a palette in Browse") }; return }
    if (!s.isReadable(def)) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("This palette lies outside the loaded files.") }; return }
    val colors = remember(rev, def) { s.readPalette(def) }
    val sel = model.selected
    var tools by remember { mutableStateOf(false) }
    val primary = (sel.firstOrNull() ?: 0).coerceIn(0, colors.size - 1)
    val cols = if (colors.size <= 16) 8 else 16
    val allPals = s.variant.allPalettes

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { model.step(-1) }, enabled = def.index > 0) { Text("<") }
            Column(Modifier.weight(1f).padding(horizontal = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                val path = s.pathOf(def)
                Text(path.first, fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(def.name, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("${def.index + 1}/${allPals.size}  -  ${colors.size} colours  -  0x%X".format(def.start + s.crcOffset), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            OutlinedButton(onClick = { model.step(1) }, enabled = def.index < allPals.size - 1) { Text(">") }
        }
        ReferenceCard(model, s, def, colors)
        // swatch grid
        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
            colors.indices.chunked(cols).forEach { rowIdx ->
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    rowIdx.forEach { i ->
                        val isSel = i in sel
                        Box(
                            Modifier.weight(1f).aspectRatio(1f).clip(RoundedCornerShape(6.dp))
                                .background(cref(colors[i], !s.alpha.isMutable))
                                .border(if (isSel) 3.dp else 1.dp, if (isSel) Color.White else Color(0x33FFFFFF), RoundedCornerShape(6.dp))
                                .combinedClickable(
                                    onClick = {
                                        if (model.multi) { if (isSel) { if (sel.size > 1) sel.remove(i) } else sel.add(i) }
                                        else { sel.clear(); sel.add(i) }
                                    },
                                    onLongClick = { model.multi = true; if (!isSel) sel.add(i) },
                                ),
                        )
                    }
                    repeat(cols - rowIdx.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            FilterChip(selected = model.multi, onClick = { model.multi = !model.multi; if (!model.multi && sel.size > 1) { val k = sel.first(); sel.clear(); sel.add(k) } }, label = { Text("Multi-select") })
            TextButton(onClick = { sel.clear(); sel.addAll(colors.indices); model.multi = true }) { Text("All") }
            Spacer(Modifier.weight(1f))
            FilledTonalButton(onClick = { tools = true }) { Text("Tools") }
        }
        ColorEditor(model, s, colors, primary)
    }
    if (tools) ToolsSheet(model, s, def, colors, onDismiss = { tools = false })
}

@Composable
fun ColorEditor(model: AppModel, s: Session, colors: IntArray, idx: Int) {
    val c = colors[idx]
    val mode = s.mode
    fun chStep(v: Int) = ColorSystem.stepFor8Bit(mode, v, false)
    val pr = ColorSystem.planeAmt(mode, false)
    val pa = ColorSystem.planeAmt(mode, true)
    fun set(r: Int, g: Int, b: Int, a: Int) {
        val n = colors.copyOf(); n[idx] = ColorSystem.rgb(r, g, b, a); model.edit(n)
    }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x22FFFFFF))) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(52.dp).clip(RoundedCornerShape(10.dp)).background(cref(c, !s.alpha.isMutable)).border(1.dp, Color(0x55FFFFFF), RoundedCornerShape(10.dp)))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Colour ${idx + 1}", fontWeight = FontWeight.SemiBold)
                    Text("#" + PaletteFormats.hex(c) + "   R${chStep(ColorSystem.red(c))} G${chStep(ColorSystem.green(c))} B${chStep(ColorSystem.blue(c))}", fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            StepSlider("R", chStep(ColorSystem.red(c)), pr, Color(0xFFFF5C5C)) { st -> set(ColorSystem.valueForStep(mode, st, false), ColorSystem.green(c), ColorSystem.blue(c), ColorSystem.alphaOf(c)) }
            StepSlider("G", chStep(ColorSystem.green(c)), pr, Color(0xFF5CFF8A)) { st -> set(ColorSystem.red(c), ColorSystem.valueForStep(mode, st, false), ColorSystem.blue(c), ColorSystem.alphaOf(c)) }
            StepSlider("B", chStep(ColorSystem.blue(c)), pr, Color(0xFF5C9CFF)) { st -> set(ColorSystem.red(c), ColorSystem.green(c), ColorSystem.valueForStep(mode, st, false), ColorSystem.alphaOf(c)) }
            if (s.alpha.isMutable) {
                StepSlider("A", ColorSystem.stepFor8Bit(mode, ColorSystem.alphaOf(c), true), pa, Color.LightGray) { st -> set(ColorSystem.red(c), ColorSystem.green(c), ColorSystem.blue(c), ColorSystem.valueForStep(mode, st, true)) }
            }
            var hex by remember(idx, c) { mutableStateOf(PaletteFormats.hex(c)) }
            OutlinedTextField(
                value = hex, onValueChange = { hex = it.take(8) }, singleLine = true, label = { Text("Hex RRGGBB") },
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                trailingIcon = {
                    TextButton(onClick = {
                        val p = PaletteFormats.parseHex(hex)
                        if (p == null) model.message = "Not a valid hex colour" else set(ColorSystem.red(p), ColorSystem.green(p), ColorSystem.blue(p), ColorSystem.alphaOf(c))
                    }) { Text("Set") }
                },
            )
        }
    }
}

@Composable
fun StepSlider(label: String, step: Int, max: Int, tint: Color, onChange: (Int) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = tint, fontWeight = FontWeight.Bold, modifier = Modifier.width(18.dp))
        Slider(
            value = step.coerceIn(0, max).toFloat(),
            onValueChange = { onChange(it.roundToInt()) },
            valueRange = 0f..max.toFloat(),
            steps = if (max in 2..64) max - 1 else 0,
            modifier = Modifier.weight(1f),
        )
        Text("$step", fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.width(34.dp))
    }
}

@Composable
fun ToolsSheet(model: AppModel, s: Session, def: PalDef, colors: IntArray, onDismiss: () -> Unit) {
    val sel = model.selected
    val clip = LocalClipboardManager.current
    var hue by remember { mutableStateOf(0f) }
    var sat by remember { mutableStateOf(1f) }
    var value by remember { mutableStateOf(1f) }
    var pendingFormat by remember { mutableStateOf(PaletteFormats.Format.ACT) }
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { u: Uri? ->
        if (u != null) {
            val bytes = if (pendingFormat == PaletteFormats.Format.PNG) pngBytes(colors) else PaletteFormats.export(pendingFormat, def.name, colors)
            model.writeBytes(u, bytes)
        }
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u: Uri? -> if (u != null) model.importPalette(u) }
    val targets: List<Int> = if (sel.size > 1) sel.toList() else colors.indices.toList()
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(if (sel.size > 1) "Applies to ${sel.size} selected colours" else "Applies to the whole palette", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            Text("Hue ${hue.roundToInt()}°", fontSize = 13.sp)
            Slider(hue, { hue = it }, valueRange = -180f..180f)
            Text("Saturation ${(sat * 100).roundToInt()}%", fontSize = 13.sp)
            Slider(sat, { sat = it }, valueRange = 0f..2f)
            Text("Brightness ${(value * 100).roundToInt()}%", fontSize = 13.sp)
            Slider(value, { value = it }, valueRange = 0f..2f)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { model.edit(PaletteOps.shiftHsv(colors, targets, hue.toDouble(), sat.toDouble(), value.toDouble())); hue = 0f; sat = 1f; value = 1f }) { Text("Apply") }
                OutlinedButton(onClick = { hue = 0f; sat = 1f; value = 1f }) { Text("Reset sliders") }
            }
            HorizontalDivider(Modifier.padding(vertical = 6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { selRange(sel)?.let { model.edit(PaletteOps.gradient(colors, it.first, it.second, false)) } ?: run { model.message = "Select 2+ colours (Multi-select)" } }) { Text("Gradient RGB") }
                OutlinedButton(onClick = { selRange(sel)?.let { model.edit(PaletteOps.gradient(colors, it.first, it.second, true)) } ?: run { model.message = "Select 2+ colours (Multi-select)" } }) { Text("Gradient HSV") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { model.edit(PaletteOps.reverse(colors, targets)) }) { Text("Reverse") }
                OutlinedButton(onClick = { model.edit(PaletteOps.invert(colors, targets)) }) { Text("Invert") }
                OutlinedButton(onClick = { model.edit(PaletteOps.grayscale(colors, targets)) }) { Text("Gray") }
            }
            HorizontalDivider(Modifier.padding(vertical = 6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { clip.setText(AnnotatedString(PaletteFormats.exportHex(colors).toString(Charsets.UTF_8))); model.message = "Palette copied" }) { Text("Copy") }
                OutlinedButton(onClick = {
                    val t = clip.getText()?.text
                    val p = if (t == null) null else PaletteFormats.import(t.toByteArray())
                    if (p == null) model.message = "Clipboard has no palette" else {
                        val n = colors.copyOf(); for (i in n.indices) if (i < p.size) n[i] = p[i]; model.edit(n)
                    }
                }) { Text("Paste") }
                OutlinedButton(onClick = { s.revert(def); model.bump() }, enabled = s.isDirty(def)) { Text("Revert") }
            }
            Text("Export palette", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
            PaletteFormats.Format.values().forEach { f ->
                OutlinedButton(onClick = { pendingFormat = f; exporter.launch(safeName(def.name) + "." + f.ext) }, modifier = Modifier.fillMaxWidth()) { Text(f.label) }
            }
            OutlinedButton(onClick = { importer.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) { Text("Import palette (.act .gpl .pal .txt)") }
            OutlinedButton(onClick = { model.needZipExport = true; onDismiss() }, modifier = Modifier.fillMaxWidth()) { Text("Export patched ROM files (.zip)...") }
        }
    }
}

private fun selRange(sel: List<Int>): Pair<Int, Int>? = if (sel.size >= 2) Pair(sel.min(), sel.max()) else null

private fun safeName(n: String): String = n.replace(Regex("[^A-Za-z0-9._-]+"), "_").take(60).ifEmpty { "palette" }

fun pngBytes(colors: IntArray): ByteArray {
    val cols = if (colors.size <= 16) colors.size.coerceAtLeast(1) else 16
    val rows = (colors.size + cols - 1) / cols
    val cell = 24
    val bmp = Bitmap.createBitmap(cols * cell, rows * cell, Bitmap.Config.ARGB_8888)
    for (i in colors.indices) {
        val c = colors[i]
        val argb = (0xFF shl 24) or (ColorSystem.red(c) shl 16) or (ColorSystem.green(c) shl 8) or ColorSystem.blue(c)
        val x0 = (i % cols) * cell; val y0 = (i / cols) * cell
        for (y in 0 until cell) for (x in 0 until cell) bmp.setPixel(x0 + x, y0 + y, argb)
    }
    val bos = ByteArrayOutputStream()
    bmp.compress(Bitmap.CompressFormat.PNG, 100, bos)
    return bos.toByteArray()
}


@Composable
fun SlotRow(model: AppModel, i: Int, spec: FileSpec) {
    var open by remember { mutableStateOf(false) }
    val k = model.assign.getOrElse(i) { -1 }
    val f = model.picked.getOrNull(k)
    val exact = f != null && f.name.equals(spec.name, true)
    Box {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).combinedClickable(onClick = { open = true })
                .background(MaterialTheme.colorScheme.background).padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(spec.name + "  (" + (spec.size / 1024) + " KB)", fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                Text(
                    if (f == null) "not chosen" else "using: " + f.name + (if (f.data.size != spec.size) "  [size differs: ${f.data.size / 1024} KB]" else "") + (if (!exact) "  (matched automatically)" else ""),
                    fontSize = 12.sp,
                    color = if (f == null) MaterialTheme.colorScheme.error else if (exact && f.data.size == spec.size) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.tertiary,
                )
            }
            Text("\u25BC")
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            model.picked.forEachIndexed { pi, pf ->
                DropdownMenuItem(text = { Text(pf.name + "  (" + pf.data.size / 1024 + " KB)") }, onClick = {
                    if (i < model.assign.size) model.assign[i] = pi
                    open = false
                })
            }
            if (model.picked.isEmpty()) DropdownMenuItem(text = { Text("Choose ROM file(s) first") }, onClick = { open = false })
        }
    }
}

@Composable
fun ReferenceCard(model: AppModel, s: Session, def: PalDef, colors: IntArray) {
    val loader = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u: Uri? -> if (u != null) model.loadRef(u) }
    val img = model.ref
    val rr = model.refRev
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x22FFFFFF))) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Reference preview", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                OutlinedButton(onClick = { loader.launch(arrayOf("image/*")) }) { Text(if (img == null) "Load image" else "Change") }
            }
            if (img == null) {
                Text("Load a sprite or screenshot that uses this palette (take one from the game or an emulator). It is matched to the palette's colours and recoloured live while you edit.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                val bmp = remember(rr, model.rev, def.index) { img.render(colors).asImageBitmap() }
                Box(Modifier.fillMaxWidth().heightIn(max = 260.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF05050A)), contentAlignment = Alignment.Center) {
                    Image(bmp, contentDescription = "preview", contentScale = ContentScale.Fit, filterQuality = FilterQuality.None, modifier = Modifier.fillMaxWidth().heightIn(max = 260.dp))
                }
                Text("Matching tolerance ${model.refTol}", fontSize = 12.sp)
                Slider(
                    value = model.refTol.toFloat(), onValueChange = { model.refTol = it.roundToInt() },
                    onValueChangeFinished = { img.map(colors, model.refTol); model.refRev++ }, valueRange = 4f..80f,
                )
                Text("If the picture shows a different palette, edit nothing, step to the right palette and tap Re-match.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { img.map(colors, model.refTol); model.refRev++ }) { Text("Re-match to this palette") }
                    TextButton(onClick = { model.ref = null }) { Text("Remove") }
                }
            }
        }
    }
}
