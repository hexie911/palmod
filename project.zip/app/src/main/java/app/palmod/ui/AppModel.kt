package app.palmod.ui

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.palmod.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

enum class Screen { Home, Setup, Dev, Editor, About }

class Origin(val uri: Uri, val entry: String?)

class AppModel(private val app: Application) : AndroidViewModel(app) {
    var screen by mutableStateOf(Screen.Home)
    var catalog by mutableStateOf<List<GameSummary>>(emptyList())
    var query by mutableStateOf("")
    var game by mutableStateOf<GameDef?>(null)
    var variantIdx by mutableIntStateOf(0)
    val picked = mutableStateListOf<RomFile>()
    var session by mutableStateOf<Session?>(null)
    var rev by mutableIntStateOf(0)
    var message by mutableStateOf<String?>(null)
    var busy by mutableStateOf(false)
    var currentPal by mutableStateOf<PalDef?>(null)
    var tab by mutableIntStateOf(0)
    val selected = mutableStateListOf<Int>()
    var multi by mutableStateOf(false)
    var needZipExport by mutableStateOf(false)
    var pendingFormat: PaletteFormats.Format = PaletteFormats.Format.ACT

    init {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val txt = app.assets.open("catalog/index.json").bufferedReader().use { it.readText() }
                val list = Catalog.parseIndex(txt)
                withContext(Dispatchers.Main) { catalog = list }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { message = "Could not load game catalog: ${e.message}" }
            }
        }
    }

    fun bump() { rev++ }

    fun openGame(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val txt = app.assets.open("catalog/games/$id.json").bufferedReader().use { it.readText() }
                val g = Catalog.parseGame(txt)
                withContext(Dispatchers.Main) {
                    game = g; variantIdx = 0; picked.clear(); screen = Screen.Setup
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { message = "Could not open game: ${e.message}" }
            }
        }
    }

    private fun displayName(uri: Uri): String {
        var n: String? = null
        try {
            app.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) n = c.getString(i)
            }
        } catch (_: Exception) { }
        return n ?: (uri.lastPathSegment ?: "file").substringAfterLast('/')
    }

    private fun readAll(uri: Uri): ByteArray =
        app.contentResolver.openInputStream(uri)!!.use { it.readBytes() }

    fun addFiles(uris: List<Uri>) {
        viewModelScope.launch(Dispatchers.IO) {
            withContext(Dispatchers.Main) { busy = true }
            val added = ArrayList<RomFile>()
            try {
                for (u in uris) {
                    val name = displayName(u)
                    try { app.contentResolver.takePersistableUriPermission(u, 3) } catch (_: Exception) { }
                    if (name.endsWith(".zip", true)) {
                        ZipInputStream(app.contentResolver.openInputStream(u)!!.buffered()).use { zin ->
                            var e: ZipEntry? = zin.nextEntry
                            while (e != null) {
                                if (!e.isDirectory) {
                                    val bos = ByteArrayOutputStream()
                                    zin.copyTo(bos)
                                    val data = bos.toByteArray()
                                    val rf = RomFile(e.name.substringAfterLast('/'), data, data.size)
                                    rf.origin = Origin(u, e.name)
                                    added.add(rf)
                                }
                                e = zin.nextEntry
                            }
                        }
                    } else {
                        val data = readAll(u)
                        val rf = RomFile(name, data, data.size)
                        rf.origin = Origin(u, null)
                        added.add(rf)
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { message = "Could not read file: ${e.message}" }
            }
            withContext(Dispatchers.Main) {
                for (f in added) {
                    picked.removeAll { it.name.equals(f.name, true) }
                    picked.add(f)
                }
                game?.let { g ->
                    RomIdentifier.bestVariant(g, picked.map { it.name })?.let { variantIdx = g.variants.indexOf(it).coerceAtLeast(0) }
                }
                busy = false
            }
        }
    }

    /** Files of [variant] resolved from the picked ones; returns null + message when something is missing. */
    private fun resolveFiles(variant: Variant): List<RomFile>? {
        val out = ArrayList<RomFile>()
        val missing = ArrayList<String>()
        for (spec in variant.files) {
            var f = picked.firstOrNull { it.name.equals(spec.name, true) }
            if (f == null && variant.files.size == 1 && picked.size == 1) f = picked[0]
            if (f == null) { missing.add(spec.name); continue }
            val rf = RomFile(f.name, f.data, spec.size)
            rf.origin = f.origin
            out.add(rf)
        }
        if (missing.isNotEmpty()) {
            message = "Missing file(s): " + missing.take(6).joinToString(", ") + if (missing.size > 6) " ..." else ""
            return null
        }
        return out
    }

    fun startGame() {
        val g = game ?: return
        val v = g.variants.getOrNull(variantIdx) ?: return
        val files = resolveFiles(v) ?: return
        val m = RomIdentifier.identify(v, files)
        val s = Session(v, RomSet(files, v.join), m.offset, m.message)
        begin(s)
    }

    fun startDev(fileName: String, data: ByteArray, origin: Origin?, mode: ColMode, alpha: AlphaMode, offset: Int, perPal: Int, count: Int) {
        val v = DevMode.variant(fileName, data.size, mode, alpha, offset, perPal, count)
        if (v.allPalettes.isEmpty()) { message = "No palette fits inside the file with those settings."; return }
        val rf = RomFile(fileName, data, data.size); rf.origin = origin
        begin(Session(v, RomSet(listOf(rf), JoinType.Sequential), 0, "Developer Mode"))
    }

    private fun begin(s: Session) {
        session = s
        currentPal = s.variant.allPalettes.firstOrNull()
        selected.clear(); selected.add(0)
        tab = 0
        screen = Screen.Editor
        bump()
    }

    fun selectPalette(d: PalDef) {
        currentPal = d; selected.clear(); selected.add(0); tab = 1; bump()
    }

    fun step(delta: Int) {
        val s = session ?: return
        val list = s.variant.allPalettes
        val cur = currentPal ?: return
        val i = (cur.index + delta).coerceIn(0, list.size - 1)
        currentPal = list[i]; selected.clear(); selected.add(0); bump()
    }

    fun edit(colors: IntArray) {
        val s = session ?: return
        val d = currentPal ?: return
        s.applyPalette(d, colors)
        bump()
    }

    fun undo() { session?.undo()?.let { currentPal = it }; bump() }
    fun redo() { session?.redo()?.let { currentPal = it }; bump() }

    fun save() {
        val s = session ?: return
        viewModelScope.launch(Dispatchers.IO) {
            var failed = false
            var written = 0
            for (f in s.rom.dirtyFiles) {
                val o = f.origin as? Origin
                if (o == null || o.entry != null) { failed = true; continue }
                try {
                    app.contentResolver.openOutputStream(o.uri, "wt")!!.use { it.write(f.data) }
                    f.dirty = false; written++
                } catch (e: Exception) { failed = true }
            }
            withContext(Dispatchers.Main) {
                if (failed) {
                    needZipExport = true
                    message = "Could not write some files in place. Use 'Export patched files (.zip)'."
                } else {
                    message = if (written == 0) "Nothing to save." else "Saved $written file(s)."
                    s.markSaved()
                }
                bump()
            }
        }
    }

    fun exportZip(uri: Uri) {
        val s = session ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val files = s.rom.files.filter { it.dirty }.ifEmpty { s.rom.files }
                app.contentResolver.openOutputStream(uri, "wt")!!.use { os ->
                    ZipOutputStream(os).use { z ->
                        for (f in files) { z.putNextEntry(ZipEntry(f.name)); z.write(f.data); z.closeEntry() }
                    }
                }
                withContext(Dispatchers.Main) { message = "Exported ${files.size} file(s) to ZIP."; needZipExport = false }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { message = "Export failed: ${e.message}" }
            }
        }
    }

    fun writeBytes(uri: Uri, bytes: ByteArray) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                app.contentResolver.openOutputStream(uri, "wt")!!.use { it.write(bytes) }
                withContext(Dispatchers.Main) { message = "Exported." }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { message = "Export failed: ${e.message}" }
            }
        }
    }

    fun importPalette(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val cols = PaletteFormats.import(readAll(uri))
                withContext(Dispatchers.Main) {
                    val s = session; val d = currentPal
                    if (cols == null || s == null || d == null) { message = "Unrecognised palette file."; return@withContext }
                    val cur = s.readPalette(d)
                    for (i in cur.indices) if (i < cols.size) cur[i] = cols[i]
                    edit(cur)
                    message = "Imported ${minOf(cols.size, cur.size)} colours."
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { message = "Import failed: ${e.message}" }
            }
        }
    }

    var devName by mutableStateOf("")
    var devData by mutableStateOf<ByteArray?>(null)
    var devOrigin: Origin? = null

    fun readDev(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                try { app.contentResolver.takePersistableUriPermission(uri, 3) } catch (_: Exception) { }
                val data = readAll(uri)
                val name = displayName(uri)
                withContext(Dispatchers.Main) { devData = data; devName = name; devOrigin = Origin(uri, null) }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { message = "Could not read file: ${e.message}" }
            }
        }
    }

    fun closeGame() { session = null; game = null; picked.clear(); screen = Screen.Home }
}
