package app.palmod.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Accent = Color(0xFFFF4FA3)
val Accent2 = Color(0xFF3DE0D0)

private val Scheme = darkColorScheme(
    primary = Accent,
    onPrimary = Color(0xFF3A0020),
    secondary = Accent2,
    onSecondary = Color(0xFF00332E),
    tertiary = Color(0xFFFFC857),
    background = Color(0xFF0E0F1A),
    onBackground = Color(0xFFE8E8F2),
    surface = Color(0xFF151728),
    onSurface = Color(0xFFE8E8F2),
    surfaceVariant = Color(0xFF22253D),
    onSurfaceVariant = Color(0xFFB9BCD6),
    primaryContainer = Color(0xFF5A1740),
    onPrimaryContainer = Color(0xFFFFD8EA),
    secondaryContainer = Color(0xFF123F3B),
    onSecondaryContainer = Color(0xFFB9FFF7),
    error = Color(0xFFFF6B6B),
)

@Composable
fun PalModTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
